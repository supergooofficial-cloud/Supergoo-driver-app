package com.supergoo.customer;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
