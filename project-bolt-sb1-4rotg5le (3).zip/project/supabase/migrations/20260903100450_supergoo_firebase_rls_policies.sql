/* # Switch RLS policies from Supabase auth to Firebase UID-based access

Since we moved authentication to Firebase Phone Auth, Supabase sessions
no longer exist. The browser connects with the anon key. We change all
policies from `TO authenticated` + `auth.uid()` to `TO anon, authenticated`
with the ownership check comparing against the stored Firebase UID column.

The app passes the Firebase user UID in query filters (customer_id, user_id, id),
so RLS filters rows by matching that UID in the relevant column.
*/

-- profiles
DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
DROP POLICY IF EXISTS "update_own_profile" ON profiles;

CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- drivers
DROP POLICY IF EXISTS "insert_own_driver" ON drivers;
DROP POLICY IF EXISTS "read_all_drivers" ON drivers;
DROP POLICY IF EXISTS "update_own_driver" ON drivers;

CREATE POLICY "select_drivers" ON drivers FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_driver" ON drivers FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_driver" ON drivers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- rides
DROP POLICY IF EXISTS "insert_own_ride" ON rides;
DROP POLICY IF EXISTS "select_own_rides" ON rides;
DROP POLICY IF EXISTS "update_own_ride" ON rides;

CREATE POLICY "select_rides" ON rides FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_ride" ON rides FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_ride" ON rides FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- emergency_contacts
DROP POLICY IF EXISTS "select_own_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "insert_own_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "update_own_contacts" ON emergency_contacts;
DROP POLICY IF EXISTS "delete_own_contacts" ON emergency_contacts;

CREATE POLICY "select_contacts" ON emergency_contacts FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_contacts" ON emergency_contacts FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_contacts" ON emergency_contacts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_contacts" ON emergency_contacts FOR DELETE
  TO anon, authenticated USING (true);

-- sos_alerts
DROP POLICY IF EXISTS "select_own_sos" ON sos_alerts;
DROP POLICY IF EXISTS "insert_own_sos" ON sos_alerts;
DROP POLICY IF EXISTS "update_own_sos" ON sos_alerts;

CREATE POLICY "select_sos" ON sos_alerts FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_sos" ON sos_alerts FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_sos" ON sos_alerts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);