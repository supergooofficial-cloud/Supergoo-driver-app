/* # SuperGoo Ride — Tables & Policies */

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text UNIQUE,
  role text NOT NULL DEFAULT 'customer',
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS drivers (
  id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  is_online boolean NOT NULL DEFAULT false,
  vehicle_number text,
  vehicle_model text,
  current_lat double precision,
  current_lng double precision,
  rating numeric DEFAULT 5.0,
  total_rides integer DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_all_drivers" ON drivers;
CREATE POLICY "read_all_drivers" ON drivers FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_driver" ON drivers;
CREATE POLICY "insert_own_driver" ON drivers FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_driver" ON drivers;
CREATE POLICY "update_own_driver" ON drivers FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS serviceable_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  district text NOT NULL,
  region text NOT NULL DEFAULT 'andhra',
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE serviceable_areas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_areas_all" ON serviceable_areas;
CREATE POLICY "read_areas_all" ON serviceable_areas FOR SELECT
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS rides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  driver_id uuid REFERENCES profiles(id),
  pickup_lat double precision NOT NULL,
  pickup_lng double precision NOT NULL,
  pickup_address text NOT NULL,
  drop_lat double precision NOT NULL,
  drop_lng double precision NOT NULL,
  drop_address text NOT NULL,
  distance_km numeric NOT NULL DEFAULT 0,
  fare numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'searching',
  driver_lat double precision,
  driver_lng double precision,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE rides ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_rides" ON rides;
CREATE POLICY "select_own_rides" ON rides FOR SELECT
  TO authenticated USING (auth.uid() = customer_id OR auth.uid() = driver_id);

DROP POLICY IF EXISTS "insert_own_ride" ON rides;
CREATE POLICY "insert_own_ride" ON rides FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = customer_id);

DROP POLICY IF EXISTS "update_own_ride" ON rides;
CREATE POLICY "update_own_ride" ON rides FOR UPDATE
  TO authenticated USING (auth.uid() = customer_id OR auth.uid() = driver_id)
  WITH CHECK (auth.uid() = customer_id OR auth.uid() = driver_id);

CREATE INDEX IF NOT EXISTS idx_rides_customer ON rides(customer_id);
CREATE INDEX IF NOT EXISTS idx_rides_driver ON rides(driver_id);
CREATE INDEX IF NOT EXISTS idx_rides_status ON rides(status);
CREATE INDEX IF NOT EXISTS idx_drivers_online ON drivers(is_online);
CREATE INDEX IF NOT EXISTS idx_areas_region ON serviceable_areas(region);