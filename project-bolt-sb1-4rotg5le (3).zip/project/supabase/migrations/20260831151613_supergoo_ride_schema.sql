/*
# SuperGoo Ride — Bike Taxi App Schema

## Overview
Creates the complete database schema for a Rapido-like bike taxi app focused on Andhra Pradesh + Konaseema.
Uses Supabase phone OTP auth for login (same real-OTP experience as Firebase Phone Auth).

## New Tables

### profiles
- `id` (uuid, PK, references auth.users) — one row per user
- `full_name` (text) — user's display name
- `phone` (text, unique) — phone number in +91 format
- `role` (text, default 'customer') — 'customer' or 'driver'
- `avatar_url` (text) — optional profile photo
- `created_at` (timestamptz)

### drivers
- `id` (uuid, PK, references profiles.id) — driver profile extension
- `is_online` (boolean, default false) — whether driver is accepting rides
- `vehicle_number` (text) — bike registration number
- `vehicle_model` (text) — e.g. "Honda Activa"
- `current_lat` (double precision) — live location
- `current_lng` (double precision) — live location
- `rating` (numeric, default 5.0) — driver rating
- `total_rides` (integer, default 0) — lifetime ride count
- `updated_at` (timestamptz) — location/timestamp last updated

### serviceable_areas
- `id` (uuid, PK)
- `name` (text) — mandal/town/village name
- `district` (text) — district name
- `region` (text) — 'konaseema' or 'andhra'
- `lat` (double precision) — approximate latitude
- `lng` (double precision) — approximate longitude
- `is_primary` (boolean) — true for Konaseema focus areas
- `created_at` (timestamptz)

### rides
- `id` (uuid, PK)
- `customer_id` (uuid, references profiles) — rider who booked
- `driver_id` (uuid, references profiles, nullable) — assigned driver
- `pickup_lat` / `pickup_lng` (double precision) — pickup point
- `pickup_address` (text) — pickup address text
- `drop_lat` / `drop_lng` (double precision) — destination
- `drop_address` (text) — destination address text
- `distance_km` (numeric) — estimated distance
- `fare` (numeric) — estimated fare in INR
- `status` (text, default 'searching') — searching/accepted/en route/started/completed/cancelled
- `driver_lat` / `driver_lng` (double precision, nullable) — live driver location during ride
- `created_at` (timestamptz)
- `completed_at` (timestamptz, nullable)

## Security (RLS)
- profiles: owner-scoped CRUD (authenticated only)
- drivers: owner can update own row; all authenticated can read (for driver list/tracking)
- serviceable_areas: readable by all (anon + authenticated), no writes from client
- rides: customer can CRUD own rides; driver can update assigned ride location/status; both can read relevant rides
*/