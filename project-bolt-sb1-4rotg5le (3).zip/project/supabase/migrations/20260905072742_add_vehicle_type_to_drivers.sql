/*
# Add vehicle_type to drivers table + expand rides vehicle_type

1. Changes
- Adds `vehicle_type` column (text) to the `drivers` table to store which vehicle type the driver owns.
- Values: 'bike', 'auto', 'cab_mini', 'cab_suv'
- Backfills existing drivers with 'bike' as default.
- The `rides.vehicle_type` column already exists as text; existing values 'bike', 'auto', 'cab' remain valid.
  New ride rows may also use 'cab_mini' and 'cab_suv'. No constraint changes needed since it's a text column.

2. Security
- No RLS policy changes. Existing policies on `drivers` and `rides` already cover CRUD operations.
*/

ALTER TABLE drivers ADD COLUMN IF NOT EXISTS vehicle_type text DEFAULT 'bike';

UPDATE drivers SET vehicle_type = 'bike' WHERE vehicle_type IS NULL;
