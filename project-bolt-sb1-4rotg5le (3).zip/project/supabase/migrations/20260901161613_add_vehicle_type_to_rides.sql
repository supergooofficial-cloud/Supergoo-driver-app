/*
# Add vehicle_type column to rides table

## Changes
- Adds `vehicle_type` column to `rides` table (text, not null, default 'bike')
- Supports 3 vehicle types: 'bike', 'auto', 'cab'
- Existing rides default to 'bike'
- No security changes needed — RLS policies already cover the table

## Notes
- The app now supports Bike, Auto, and Cab/Mini like Rapido + Uber
- Fare calculation differs per vehicle type (handled in app code)
*/

ALTER TABLE rides
  ADD COLUMN IF NOT EXISTS vehicle_type text NOT NULL DEFAULT 'bike';

-- Backfill any existing rows
UPDATE rides SET vehicle_type = 'bike' WHERE vehicle_type IS NULL;