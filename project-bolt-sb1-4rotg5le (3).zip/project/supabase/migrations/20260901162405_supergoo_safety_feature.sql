/*
# SuperGoo Ride — Women Safety SOS Feature

## New Tables

### emergency_contacts
- Stores up to 3 emergency contacts per user (Mother, Father, Friend)
- `id` (uuid PK)
- `user_id` (uuid → profiles.id)
- `name` (text) — contact display name
- `phone` (text) — phone number in +91 format
- `relationship` (text) — 'mother' | 'father' | 'friend' | 'other'

### sos_alerts
- Log of every SOS triggered during a ride
- `id` (uuid PK)
- `ride_id` (uuid → rides.id, nullable)
- `user_id` (uuid → profiles.id)
- `lat` / `lng` (double precision) — GPS location at trigger time
- `status` (text) — 'active' | 'resolved' | 'cancelled'
- `created_at` (timestamptz)

## Profile additions
- `gender` (text, nullable) — 'male' | 'female' | 'other'
- `safety_mode` (boolean, default false) — Women Safety Mode toggle

## Security (RLS)
- emergency_contacts: owner-scoped CRUD
- sos_alerts: owner can insert/read; owner can update own
*/