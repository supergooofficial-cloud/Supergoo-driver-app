/*
# Add ride_otp column to rides table

1. Changes
- Adds `ride_otp` column (text, 4 characters) to the `rides` table.
- This column stores a random 4-digit OTP generated at booking time.
- The customer shares this OTP with the driver, who must enter it correctly to start the ride.
- Backfilled existing rows with a default random 4-digit OTP so they are not null.

2. Security
- No RLS policy changes. The existing policies on `rides` already cover SELECT/INSERT/UPDATE/DELETE.
- The `ride_otp` is visible to both customer and driver for the ride they are parties to, which is the intended behavior.

3. Important notes
- The OTP is generated client-side at booking time and stored in the database.
- The driver reads the OTP from the ride row (they can see it in the incoming ride request).
- The customer also reads it from the ride row in the tracking screen.
- Validation happens client-side: the driver enters the OTP and the app compares it to the stored value before updating status to 'started'.
*/

ALTER TABLE rides ADD COLUMN IF NOT EXISTS ride_otp text;

-- Backfill existing rows with a random 4-digit OTP
UPDATE rides SET ride_otp = lpad(floor(random() * 10000)::int::text, 4, '0') WHERE ride_otp IS NULL;
