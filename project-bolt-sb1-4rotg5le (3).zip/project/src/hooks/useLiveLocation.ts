import { useState, useEffect, useCallback } from 'react';

type LocationState = {
  lat: number | null;
  lng: number | null;
  loading: boolean;
  error: string | null;
};

export function useLiveLocation(autoFetch = true) {
  const [state, setState] = useState<LocationState>({
    lat: null,
    lng: null,
    loading: autoFetch,
    error: null,
  });

  const fetch = useCallback(() => {
    if (!navigator.geolocation) {
      setState((s) => ({
        ...s,
        loading: false,
        error: 'Geolocation not supported on this device',
      }));
      return;
    }
    setState((s) => ({ ...s, loading: true, error: null }));
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setState({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          loading: false,
          error: null,
        });
      },
      (err) => {
        let msg = 'Could not get your location';
        if (err.code === err.PERMISSION_DENIED)
          msg = 'Location permission denied. Please enable it in your browser.';
        else if (err.code === err.POSITION_UNAVAILABLE)
          msg = 'Location unavailable. Try again.';
        else if (err.code === err.TIMEOUT) msg = 'Location request timed out';
        setState({ lat: null, lng: null, loading: false, error: msg });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  }, []);

  useEffect(() => {
    if (autoFetch) fetch();
  }, [autoFetch, fetch]);

  return { ...state, refresh: fetch };
}
