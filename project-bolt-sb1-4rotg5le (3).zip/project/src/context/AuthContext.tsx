import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  onAuthStateChanged,
  signInWithPhoneNumber,
  signOut as firebaseSignOut,
  type User as FirebaseUser,
  type ConfirmationResult,
  RecaptchaVerifier,
} from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { supabase, type Profile } from '@/lib/supabase';

type AuthContextValue = {
  firebaseUser: FirebaseUser | null;
  profile: Profile | null;
  loading: boolean;
  sendOtp: (
    phone: string,
    containerId: string,
  ) => Promise<ConfirmationResult>;
  verifyOtp: (
    confirmation: ConfirmationResult,
    code: string,
  ) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadProfile(uid: string, phone: string | null) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .maybeSingle();
    if (error) {
      console.error('Profile load error', error);
      return;
    }
    if (data) {
      setProfile(data as Profile);
      return;
    }
    const { data: inserted } = await supabase
      .from('profiles')
      .insert({
        id: uid,
        phone,
        role: 'customer',
        safety_mode: false,
      })
      .select()
      .maybeSingle();
    if (inserted) setProfile(inserted as Profile);
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (user) {
        const phone = user.phoneNumber ?? null;
        loadProfile(user.uid, phone).finally(() => setLoading(false));
      } else {
        setProfile(null);
        setLoading(false);
      }
    });
    return () => unsub();
  }, []);

  const recaptchaRef = useRef<RecaptchaVerifier | null>(null);

  const sendOtp = async (
    phone: string,
    containerId: string,
  ): Promise<ConfirmationResult> => {
    if (recaptchaRef.current) {
      try { recaptchaRef.current.clear(); } catch { /* noop */ }
      recaptchaRef.current = null;
    }
    const recaptcha = new RecaptchaVerifier(auth, containerId, {
      size: 'normal',
      callback: () => {},
    });
    recaptchaRef.current = recaptcha;
    const result = await signInWithPhoneNumber(auth, phone, recaptcha);
    return result;
  };

  const verifyOtp = async (
    confirmation: ConfirmationResult,
    code: string,
  ): Promise<void> => {
    await confirmation.confirm(code);
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
    setProfile(null);
  };

  const refreshProfile = async () => {
    if (firebaseUser) {
      await loadProfile(firebaseUser.uid, firebaseUser.phoneNumber ?? null);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        loading,
        sendOtp,
        verifyOtp,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
