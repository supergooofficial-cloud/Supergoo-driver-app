import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { Capacitor } from '@capacitor/core';
import { PushNotifications, type PushNotificationToken } from '@capacitor/push-notifications';

const firebaseConfig = {
  apiKey: 'AIzaSyAuxkaggfJI2jwp_nmWM579xhnE85TVqk8',
  authDomain: 'supergoo-ride.firebaseapp.com',
  projectId: 'supergoo-ride',
  storageBucket: 'supergoo-ride.firebasestorage.app',
  messagingSenderId: '885144883557',
  appId: '1:885144883557:web:189984d4cdeb7667ef118c',
  measurementId: 'G-J3QCCBHV8T',
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

export let analytics: ReturnType<typeof getAnalytics> | null = null;
isSupported()
  .then((ok) => {
    if (ok) analytics = getAnalytics(app);
  })
  .catch(() => {});

export { app };

export type FcmToken = string | null;

export async function initPushNotifications(): Promise<FcmToken> {
  const platform = Capacitor.getPlatform();
  if (platform !== 'android') return null;

  try {
    let permGranted = false;
    const permStatus = await PushNotifications.checkPermissions();
    if (permStatus.receive === 'prompt') {
      const req = await PushNotifications.requestPermissions();
      permGranted = req.receive === 'granted';
    } else {
      permGranted = permStatus.receive === 'granted';
    }
    if (!permGranted) return null;

    await PushNotifications.register();

    return new Promise<FcmToken>((resolve) => {
      let resolved = false;
      PushNotifications.addListener('registration', (token: PushNotificationToken) => {
        if (!resolved) { resolved = true; resolve(token.value); }
      });
      PushNotifications.addListener('registrationError', () => {
        if (!resolved) { resolved = true; resolve(null); }
      });
      setTimeout(() => { if (!resolved) { resolved = true; resolve(null); } }, 5000);
    });
  } catch {
    return null;
  }
}

export function onPushNotificationReceived(
  callback: (title: string, body: string) => void,
): () => void {
  if (Capacitor.getPlatform() !== 'android') return () => {};
  let active = true;
  PushNotifications.addListener('pushNotificationReceived', (notification) => {
    if (active) callback(notification.title ?? '', notification.body ?? '');
  });
  return () => { active = false; };
}
