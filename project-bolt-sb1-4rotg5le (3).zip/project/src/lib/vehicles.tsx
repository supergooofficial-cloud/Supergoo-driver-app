import { Bike, Car, type LucideIcon } from 'lucide-react';
import type { VehicleType } from '@/lib/supabase';

// Custom Auto-rickshaw icon component
function AutoIcon({ className, strokeWidth }: { className?: string; strokeWidth?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth ?? 2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M3 17h13a4 4 0 0 0 4-4v-1a3 3 0 0 0-3-3h-2l-2-3H6L4 10" />
      <circle cx="7" cy="18" r="2" />
      <circle cx="16" cy="18" r="2" />
      <path d="M4 10h13" />
    </svg>
  );
}

// Custom SUV icon component
function SuvIcon({ className, strokeWidth }: { className?: string; strokeWidth?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth ?? 2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-1H6v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z" />
      <circle cx="7" cy="17" r="2" />
      <circle cx="17" cy="17" r="2" />
      <path d="M7 13h10" />
    </svg>
  );
}

export type VehicleConfig = {
  id: VehicleType;
  label: string;
  subLabel: string;
  capacity: string;
  base: number;
  perKm: number;
  perMin: number;
  etaMultiplier: number;
  icon: LucideIcon | typeof AutoIcon;
  color: string;
  activeColor: string;
  activeBg: string;
  mapIconColor: string;
};

export const VEHICLES: VehicleConfig[] = [
  {
    id: 'bike',
    label: 'Bike',
    subLabel: 'Quickest & cheapest',
    capacity: '1 person',
    base: 25,
    perKm: 7,
    perMin: 1,
    etaMultiplier: 1,
    icon: Bike,
    color: 'text-primary-600',
    activeColor: 'text-primary-600',
    activeBg: 'bg-primary-50 ring-primary-200',
    mapIconColor: '#1a87ef',
  },
  {
    id: 'auto',
    label: 'Auto',
    subLabel: 'Affordable & comfortable',
    capacity: '1-3 persons',
    base: 35,
    perKm: 14,
    perMin: 1.5,
    etaMultiplier: 1.2,
    icon: AutoIcon,
    color: 'text-accent-600',
    activeColor: 'text-accent-600',
    activeBg: 'bg-accent-50 ring-accent-200',
    mapIconColor: '#fa9c00',
  },
  {
    id: 'cab_mini',
    label: 'Cab Mini',
    subLabel: 'AC car for 4',
    capacity: '1-4 persons',
    base: 60,
    perKm: 15,
    perMin: 2,
    etaMultiplier: 1.4,
    icon: Car,
    color: 'text-success-600',
    activeColor: 'text-success-600',
    activeBg: 'bg-success-50 ring-success-200',
    mapIconColor: '#10b981',
  },
  {
    id: 'cab_suv',
    label: 'Cab SUV',
    subLabel: 'Spacious for 6',
    capacity: '1-6 persons',
    base: 80,
    perKm: 18,
    perMin: 2.5,
    etaMultiplier: 1.6,
    icon: SuvIcon,
    color: 'text-neutral-700',
    activeColor: 'text-neutral-700',
    activeBg: 'bg-neutral-100 ring-neutral-300',
    mapIconColor: '#374151',
  },
];

export const VEHICLE_MAP: Record<VehicleType, VehicleConfig> = {
  bike: VEHICLES[0],
  auto: VEHICLES[1],
  cab_mini: VEHICLES[2],
  cab_suv: VEHICLES[3],
};

export function getVehicle(id: VehicleType): VehicleConfig {
  return VEHICLE_MAP[id] ?? VEHICLES[0];
}

// SVG data URLs for map markers, keyed by vehicle type
export function vehicleMarkerSvg(vehicle: VehicleType): string {
  const cfg = getVehicle(vehicle);
  const color = cfg.mapIconColor;
  if (vehicle === 'bike') {
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="' +
      color +
      '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><path d="M15 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 11.5V14l-3-3 4-3 2 3h2"/></svg>'
    );
  }
  if (vehicle === 'auto') {
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="' +
      color +
      '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17h13a4 4 0 0 0 4-4v-1a3 3 0 0 0-3-3h-2l-2-3H6L4 10"/><circle cx="7" cy="18" r="2"/><circle cx="16" cy="18" r="2"/><path d="M4 10h13"/></svg>'
    );
  }
  if (vehicle === 'cab_suv') {
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="' +
      color +
      '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-1H6v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M7 13h10"/></svg>'
    );
  }
  // cab_mini
  return (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="' +
    color +
    '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 17h14l-1.5-5.5A2 2 0 0 0 15.6 10H8.4a2 2 0 0 0-1.9 1.5L5 17z"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="17.5" r="2.5"/><path d="M8 10V7h8v3"/></svg>'
  );
}
