import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Gender = 'male' | 'female' | 'other';

export type Profile = {
  id: string;
  full_name: string | null;
  phone: string | null;
  role: 'customer' | 'driver';
  avatar_url: string | null;
  gender: Gender | null;
  safety_mode: boolean;
};

export type EmergencyContact = {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  relationship: 'mother' | 'father' | 'friend' | 'other';
  created_at: string;
};

export type SosStatus = 'active' | 'resolved' | 'cancelled';

export type SosAlert = {
  id: string;
  ride_id: string | null;
  user_id: string;
  lat: number;
  lng: number;
  status: SosStatus;
  created_at: string;
};

export type Driver = {
  id: string;
  is_online: boolean;
  vehicle_number: string | null;
  vehicle_model: string | null;
  vehicle_type: VehicleType | null;
  current_lat: number | null;
  current_lng: number | null;
  rating: number;
  total_rides: number;
  updated_at: string;
};

export type ServiceableArea = {
  id: string;
  name: string;
  district: string;
  region: 'konaseema' | 'andhra';
  lat: number;
  lng: number;
  is_primary: boolean;
};

export type RideStatus =
  | 'searching_driver'
  | 'searching'
  | 'accepted'
  | 'en_route'
  | 'started'
  | 'completed'
  | 'cancelled';

export type VehicleType = 'bike' | 'auto' | 'cab_mini' | 'cab_suv';

export type Ride = {
  id: string;
  customer_id: string;
  driver_id: string | null;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address: string;
  drop_lat: number;
  drop_lng: number;
  drop_address: string;
  distance_km: number;
  fare: number;
  status: RideStatus;
  vehicle_type: VehicleType;
  driver_lat: number | null;
  driver_lng: number | null;
  ride_otp: string | null;
  created_at: string;
  completed_at: string | null;
};
