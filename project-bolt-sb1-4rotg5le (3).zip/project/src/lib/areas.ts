import { supabase, type ServiceableArea } from './supabase';

let cache: ServiceableArea[] | null = null;

export async function getAreas(): Promise<ServiceableArea[]> {
  if (cache) return cache;
  const { data, error } = await supabase
    .from('serviceable_areas')
    .select('*')
    .order('is_primary', { ascending: false })
    .order('name', { ascending: true });
  if (error) throw error;
  cache = data as ServiceableArea[];
  return cache;
}

const EARTH_RADIUS_KM = 6371;

export function haversine(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function nearestArea(
  lat: number,
  lng: number,
  areas: ServiceableArea[],
): { area: ServiceableArea; distance: number } | null {
  if (areas.length === 0) return null;
  let best = areas[0];
  let bestDist = haversine(lat, lng, best.lat, best.lng);
  for (const area of areas) {
    const d = haversine(lat, lng, area.lat, area.lng);
    if (d < bestDist) {
      bestDist = d;
      best = area;
    }
  }
  return { area: best, distance: bestDist };
}

export function isInServiceArea(
  lat: number,
  lng: number,
  areas: ServiceableArea[],
): boolean {
  const nearest = nearestArea(lat, lng, areas);
  if (!nearest) return false;
  return nearest.distance < 60;
}

import { calculateFare } from './fare';

export function estimateFare(distanceKm: number): {
  base: number;
  perKm: number;
  total: number;
} {
  const fare = calculateFare(distanceKm, Math.max(5, Math.round(distanceKm * 3)), 'bike');
  return { base: fare.baseFare, perKm: 7, total: fare.total };
}
