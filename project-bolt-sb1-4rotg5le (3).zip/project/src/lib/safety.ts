import { supabase, type EmergencyContact, type SosAlert } from './supabase';

export async function getEmergencyContacts(
  userId: string,
): Promise<EmergencyContact[]> {
  const { data, error } = await supabase
    .from('emergency_contacts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as EmergencyContact[];
}

export async function addEmergencyContact(
  userId: string,
  name: string,
  phone: string,
  relationship: EmergencyContact['relationship'],
): Promise<EmergencyContact> {
  const { data, error } = await supabase
    .from('emergency_contacts')
    .insert({
      user_id: userId,
      name: name.trim(),
      phone: phone.trim(),
      relationship,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as EmergencyContact;
}

export async function deleteEmergencyContact(id: string): Promise<void> {
  const { error } = await supabase
    .from('emergency_contacts')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

export async function triggerSos(
  userId: string,
  lat: number,
  lng: number,
  rideId: string | null,
): Promise<SosAlert> {
  const { data, error } = await supabase
    .from('sos_alerts')
    .insert({
      user_id: userId,
      ride_id: rideId,
      lat,
      lng,
      status: 'active',
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as SosAlert;
}

export async function resolveSos(id: string): Promise<void> {
  await supabase.from('sos_alerts').update({ status: 'resolved' }).eq('id', id);
}

export function buildSosMessage(
  userName: string,
  lat: number,
  lng: number,
  rideId: string | null,
): string {
  const mapsLink = `https://maps.google.com/?q=${lat},${lng}`;
  const ridePart = rideId ? `Ride ID: ${rideId}\n` : '';
  return (
    `🚨 SOS ALERT 🚨\n` +
    `${userName} has triggered an emergency SOS from SuperGoo Ride.\n\n` +
    `${ridePart}` +
    `Live Location: ${mapsLink}\n\n` +
    `Please contact them immediately or call 112 if unreachable.`
  );
}

export function openWhatsApp(phone: string, message: string): void {
  const cleanPhone = phone.replace(/[^\d]/g, '');
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

export function sendSms(phone: string, message: string): void {
  const cleanPhone = phone.replace(/[^\d]/g, '');
  const url = `sms:${cleanPhone}?body=${encodeURIComponent(message)}`;
  window.location.href = url;
}

export function callNumber(phone: string): void {
  window.location.href = `tel:${phone}`;
}

export function buildRideShareMessage(
  userName: string,
  rideId: string,
  lat: number,
  lng: number,
): string {
  const mapsLink = `https://maps.google.com/?q=${lat},${lng}`;
  return (
    `🚗 SuperGoo Ride Tracking\n\n` +
    `${userName} is on a SuperGoo Ride and sharing their live location with you.\n\n` +
    `Track here: ${mapsLink}\n` +
    `Ride ID: ${rideId}\n\n` +
    `Powered by SuperGoo Ride — Bike, Auto & Cab for Andhra & Konaseema.`
  );
}
