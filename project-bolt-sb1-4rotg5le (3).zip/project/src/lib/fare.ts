import { getVehicle } from '@/lib/vehicles';
import type { VehicleType } from '@/lib/supabase';

export type FareBreakdown = {
  distanceKm: number;
  durationMin: number;
  baseFare: number;
  distanceCharge: number;
  timeCharge: number;
  nightSurcharge: number;
  rawTotal: number;
  total: number;
  isNight: boolean;
};

const NIGHT_SURCHARGE = 10;

function isNightTime(): boolean {
  const hour = new Date().getHours();
  return hour >= 21 || hour < 5;
}

export function calculateFare(
  distanceKm: number,
  durationMin: number,
  vehicleType: VehicleType = 'auto',
): FareBreakdown {
  const cfg = getVehicle(vehicleType);
  const isNight = isNightTime();

  const baseFare = cfg.base;
  const distanceCharge = distanceKm * cfg.perKm;
  const timeCharge = durationMin * cfg.perMin;
  const nightSurcharge = isNight ? NIGHT_SURCHARGE : 0;

  const rawTotal = baseFare + distanceCharge + timeCharge + nightSurcharge;
  const total = Math.round(rawTotal);

  return {
    distanceKm: Math.round(distanceKm * 10) / 10,
    durationMin: Math.round(durationMin),
    baseFare,
    distanceCharge: Math.round(distanceCharge),
    timeCharge: Math.round(timeCharge),
    nightSurcharge,
    rawTotal: Math.round(rawTotal),
    total,
    isNight,
  };
}

export function calculateFareForAllVehicles(
  distanceKm: number,
  durationMin: number,
): Record<VehicleType, FareBreakdown> {
  const result = {} as Record<VehicleType, FareBreakdown>;
  for (const vt of ['bike', 'auto', 'cab_mini', 'cab_suv'] as VehicleType[]) {
    result[vt] = calculateFare(distanceKm, durationMin, vt);
  }
  return result;
}

const GOOGLE_MAPS_API_KEY = import.meta.env
  .VITE_GOOGLE_MAPS_API_KEY as string;

export type RouteInfo = { distanceKm: number; durationMin: number };

export async function fetchRouteInfo(
  origin: { lat: number; lng: number },
  destination: { lat: number; lng: number },
): Promise<RouteInfo | null> {
  try {
    const url =
      `https://maps.googleapis.com/maps/api/distancematrix/json` +
      `?origins=${origin.lat},${origin.lng}` +
      `&destinations=${destination.lat},${destination.lng}` +
      `&units=metric` +
      `&key=${GOOGLE_MAPS_API_KEY}`;

    const res = await fetch(url);
    const data = await res.json();

    if (
      data.status === 'OK' &&
      data.rows?.[0]?.elements?.[0]?.status === 'OK'
    ) {
      const element = data.rows[0].elements[0];
      return {
        distanceKm: element.distance.value / 1000,
        durationMin: element.duration.value / 60,
      };
    }
    return null;
  } catch {
    return null;
  }
}
