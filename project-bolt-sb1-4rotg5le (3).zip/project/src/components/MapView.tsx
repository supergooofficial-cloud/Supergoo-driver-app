import { useEffect, useRef, useMemo } from 'react';
import {
  GoogleMap,
  useJsApiLoader,
  Marker,
  Polyline,
  Circle,
} from '@react-google-maps/api';
import { vehicleMarkerSvg } from '@/lib/vehicles';
import type { VehicleType } from '@/lib/supabase';

const GOOGLE_MAPS_API_KEY = import.meta.env
  .VITE_GOOGLE_MAPS_API_KEY as string;

const containerStyle = {
  width: '100%',
  height: '100%',
};

const mapOptions: google.maps.MapOptions = {
  zoomControl: true,
  streetViewControl: false,
  mapTypeControl: false,
  fullscreenControl: false,
  clickableIcons: false,
  disableDefaultUI: false,
  styles: [
    { featureType: 'poi', stylers: [{ visibility: 'simplified' }] },
    { featureType: 'transit', stylers: [{ visibility: 'off' }] },
  ],
};

type MapMarker =
  | { type: 'user'; lat: number; lng: number }
  | { type: 'driver'; lat: number; lng: number; vehicle?: VehicleType }
  | { type: 'pickup'; lat: number; lng: number }
  | { type: 'drop'; lat: number; lng: number };

type MapViewProps = {
  center: [number, number];
  zoom?: number;
  markers?: MapMarker[];
  route?: [[number, number], [number, number]] | null;
  className?: string;
  onMapClick?: (lat: number, lng: number) => void;
  fitToMarkers?: boolean;
};

export default function MapView({
  center,
  zoom = 14,
  markers = [],
  route = null,
  className = '',
  onMapClick,
  fitToMarkers = false,
}: MapViewProps) {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: GOOGLE_MAPS_API_KEY,
  });

  const mapRef = useRef<google.maps.Map | null>(null);
  const boundsRef = useRef<google.maps.LatLngBounds | null>(null);

  const centerLatLng = useMemo(
    () => ({ lat: center[0], lng: center[1] }),
    [center[0], center[1]],
  );

  useEffect(() => {
    if (!mapRef.current || !fitToMarkers || markers.length === 0) return;
    const bounds = new google.maps.LatLngBounds();
    for (const m of markers) {
      bounds.extend({ lat: m.lat, lng: m.lng });
    }
    if (route) {
      bounds.extend({ lat: route[0][0], lng: route[0][1] });
      bounds.extend({ lat: route[1][0], lng: route[1][1] });
    }
    mapRef.current.fitBounds(bounds, 60);
  }, [markers, route, fitToMarkers]);

  const onLoad = (map: google.maps.Map) => {
    mapRef.current = map;
    boundsRef.current = new google.maps.LatLngBounds();
  };

  const onUnmount = () => {
    mapRef.current = null;
  };

  const handleClick = (e: google.maps.MapMouseEvent) => {
    if (onMapClick && e.latLng) {
      onMapClick(e.latLng.lat(), e.latLng.lng());
    }
  };

  if (!isLoaded) {
    return (
      <div
        className={`flex h-full w-full items-center justify-center bg-neutral-100 ${className}`}
      >
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-neutral-300 border-t-primary-600" />
      </div>
    );
  }

  const routePath =
    route
      ? [
          { lat: route[0][0], lng: route[0][1] },
          { lat: route[1][0], lng: route[1][1] },
        ]
      : null;

  return (
    <div className={`h-full w-full ${className}`}>
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={centerLatLng}
        zoom={zoom}
        options={mapOptions}
        onLoad={onLoad}
        onUnmount={onUnmount}
        onClick={handleClick}
      >
        {markers.map((m, i) => {
          const pos = { lat: m.lat, lng: m.lng };
          if (m.type === 'user') {
            return (
              <Circle
                key={`user-${i}`}
                center={pos}
                radius={80}
                options={{
                  fillColor: '#1a87ef',
                  fillOpacity: 0.15,
                  strokeColor: '#1a87ef',
                  strokeOpacity: 0.5,
                  strokeWeight: 1,
                }}
              />
            );
          }
          if (m.type === 'driver') {
            const svg = vehicleMarkerSvg(m.vehicle ?? 'bike');
            const icon: google.maps.Icon = {
              url: 'data:image/svg+xml,' + encodeURIComponent(svg),
              scaledSize: new google.maps.Size(38, 38),
            };
            return <Marker key={`driver-${i}`} position={pos} icon={icon} />;
          }
          if (m.type === 'pickup') {
            return (
              <Marker
                key={`pickup-${i}`}
                position={pos}
                icon={{
                  path: google.maps.SymbolPath.CIRCLE,
                  scale: 8,
                  fillColor: '#10b981',
                  fillOpacity: 1,
                  strokeColor: '#fff',
                  strokeWeight: 2,
                }}
              />
            );
          }
          // drop
          return (
            <Marker
              key={`drop-${i}`}
              position={pos}
              icon={{
                path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
                scale: 6,
                fillColor: '#ef4444',
                fillOpacity: 1,
                strokeColor: '#fff',
                strokeWeight: 1,
              }}
            />
          );
        })}

        {routePath && (
          <Polyline
            path={routePath}
            options={{
              strokeColor: '#1a87ef',
              strokeWeight: 4,
              strokeOpacity: 0.7,
              geodesic: true,
            }}
          />
        )}
      </GoogleMap>
    </div>
  );
}
