import { Home, History, User } from 'lucide-react';

export type Tab = 'home' | 'history' | 'profile';

export default function BottomNav({
  active,
  onChange,
}: {
  active: Tab;
  onChange: (tab: Tab) => void;
}) {
  const tabs: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: 'home', label: 'Ride', icon: Home },
    { id: 'history', label: 'Rides', icon: History },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="relative z-20 flex items-center justify-around border-t border-neutral-100 bg-white px-2 py-2 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
      {tabs.map((tab) => {
        const isActive = active === tab.id;
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className="group relative flex flex-1 flex-col items-center gap-1 py-2"
          >
            <div
              className={`flex h-9 w-16 items-center justify-center rounded-full transition-all ${
                isActive
                  ? 'bg-primary-50'
                  : 'group-hover:bg-neutral-50'
              }`}
            >
              <Icon
                className={`h-5 w-5 transition-colors ${
                  isActive ? 'text-primary-600' : 'text-neutral-400'
                }`}
                strokeWidth={isActive ? 2.5 : 2}
              />
            </div>
            <span
              className={`text-xs font-medium transition-colors ${
                isActive ? 'text-primary-600' : 'text-neutral-400'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
