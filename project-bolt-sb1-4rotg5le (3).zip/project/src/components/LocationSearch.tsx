import { useState, useRef, useEffect } from 'react';
import { Search, MapPin, X, Navigation } from 'lucide-react';
import { getAreas, haversine } from '@/lib/areas';
import type { ServiceableArea } from '@/lib/supabase';

type Place = {
  name: string;
  lat: number;
  lng: number;
  district?: string;
};

type LocationSearchProps = {
  label: string;
  icon: 'pickup' | 'drop' | 'search';
  placeholder?: string;
  value: Place | null;
  onSelect: (place: Place) => void;
  userLat?: number;
  userLng?: number;
};

export default function LocationSearch({
  label,
  icon,
  placeholder = 'Search location',
  value,
  onSelect,
  userLat,
  userLng,
}: LocationSearchProps) {
  const [query, setQuery] = useState(value?.name ?? '');
  const [open, setOpen] = useState(false);
  const [areas, setAreas] = useState<ServiceableArea[]>([]);
  const [results, setResults] = useState<Place[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getAreas().then(setAreas).catch(() => {});
  }, []);

  useEffect(() => {
    setQuery(value?.name ?? '');
  }, [value]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!open) return;
    const q = query.trim().toLowerCase();
    let list: Place[] = areas.map((a) => ({
      name: a.name,
      lat: a.lat,
      lng: a.lng,
      district: a.district,
    }));
    if (q) {
      list = list
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            (p.district ?? '').toLowerCase().includes(q),
        )
        .sort((a, b) => {
          const an = a.name.toLowerCase().startsWith(q) ? 0 : 1;
          const bn = b.name.toLowerCase().startsWith(q) ? 0 : 1;
          return an - bn;
        });
    } else if (userLat != null && userLng != null) {
      list = list
        .map((p) => ({
          ...p,
          _dist: haversine(userLat, userLng, p.lat, p.lng),
        }))
        .sort((a, b) => (a._dist ?? 0) - (b._dist ?? 0))
        .slice(0, 8);
    } else {
      list = list.slice(0, 8);
    }
    setResults(list.slice(0, 8));
  }, [query, open, areas, userLat, userLng]);

  const iconEl =
    icon === 'pickup' ? (
      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success-100">
        <MapPin className="h-4 w-4 text-success-600" />
      </div>
    ) : icon === 'drop' ? (
      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-error-100">
        <Navigation className="h-4 w-4 text-error-600" />
      </div>
    ) : (
      <Search className="h-5 w-5 text-neutral-400" />
    );

  return (
    <div ref={containerRef} className="relative">
      {label && (
        <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
          {label}
        </label>
      )}
      <div className="flex items-center gap-3 rounded-xl border border-neutral-200 bg-white px-3.5 py-3 transition-all focus-within:border-primary-500 focus-within:ring-4 focus-within:ring-primary-500/10">
        {iconEl}
        <input
          type="text"
          className="flex-1 bg-transparent text-sm font-medium text-neutral-900 placeholder-neutral-400 focus:outline-none"
          placeholder={placeholder}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
        />
        {query && (
          <button
            onClick={() => {
              setQuery('');
              setOpen(false);
            }}
            className="text-neutral-400 hover:text-neutral-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {open && results.length > 0 && (
        <div className="absolute z-30 mt-2 w-full overflow-hidden rounded-xl border border-neutral-100 bg-white shadow-xl animate-fade-in">
          {userLat != null && !query.trim() && (
            <button
              className="flex w-full items-center gap-3 border-b border-neutral-50 px-4 py-3 text-left hover:bg-primary-50"
              onClick={() => {
                onSelect({
                  name: 'Current Location',
                  lat: userLat,
                  lng: userLng ?? 0,
                });
                setOpen(false);
              }}
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-100">
                <Navigation className="h-4 w-4 text-primary-600" />
              </div>
              <div>
                <p className="text-sm font-semibold text-primary-700">
                  Use Current Location
                </p>
                <p className="text-xs text-neutral-400">Auto-detect from GPS</p>
              </div>
            </button>
          )}
          {results.map((r) => (
            <button
              key={`${r.name}-${r.lat}`}
              className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-neutral-50"
              onClick={() => {
                onSelect(r);
                setQuery(r.name);
                setOpen(false);
              }}
            >
              <MapPin className="h-4 w-4 flex-shrink-0 text-neutral-400" />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-neutral-800">
                  {r.name}
                </p>
                {r.district && (
                  <p className="truncate text-xs text-neutral-400">
                    {r.district} District
                  </p>
                )}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}


