import { ShieldAlert } from 'lucide-react';

export default function SosButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group relative flex h-16 w-16 items-center justify-center rounded-full bg-error-600 text-white shadow-xl shadow-error-600/40 transition-transform active:scale-90"
      title="SOS — Emergency"
      aria-label="SOS Emergency Button"
    >
      {/* Pulse rings */}
      <span className="absolute inset-0 animate-pulse-ring rounded-full bg-error-400" />
      <span
        className="absolute inset-0 animate-pulse-ring rounded-full bg-error-400"
        style={{ animationDelay: '0.5s' }}
      />

      {/* Inner badge */}
      <span className="relative flex flex-col items-center">
        <ShieldAlert className="h-6 w-6" strokeWidth={2.5} />
        <span className="mt-0.5 text-[9px] font-extrabold tracking-wider">SOS</span>
      </span>
    </button>
  );
}
