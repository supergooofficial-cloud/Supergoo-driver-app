import { useState } from 'react';
import {
  ShieldAlert,
  Phone,
  MessageCircle,
  MapPin,
  X,
  CheckCircle2,
  Loader2,
  Users,
} from 'lucide-react';
import type { EmergencyContact, Ride } from '@/lib/supabase';
import {
  triggerSos,
  buildSosMessage,
  openWhatsApp,
  sendSms,
  callNumber,
} from '@/lib/safety';

type Phase = 'confirm' | 'sending' | 'sent' | 'contacts';

export default function SosModal({
  ride,
  userId,
  userName,
  contacts,
  lat,
  lng,
  onClose,
}: {
  ride: Ride | null;
  userId: string;
  userName: string;
  contacts: EmergencyContact[];
  lat: number;
  lng: number;
  onClose: () => void;
}) {
  const [phase, setPhase] = useState<Phase>('confirm');
  const [sentCount, setSentCount] = useState(0);

  const handleSos = async () => {
    setPhase('sending');
    try {
      await triggerSos(userId, lat, lng, ride?.id ?? null);
      const message = buildSosMessage(userName, lat, lng, ride?.id ?? null);

      let count = 0;
      for (const contact of contacts) {
        openWhatsApp(contact.phone, message);
        count++;
        setSentCount(count);
      }
      // Also send via SMS for contacts without WhatsApp
      for (const contact of contacts) {
        sendSms(contact.phone, message);
      }
      setPhase('sent');
    } catch {
      setPhase('sent');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-white shadow-2xl animate-bounce-in">
        {/* Header */}
        <div className="bg-gradient-to-br from-error-500 to-error-700 px-5 py-5 text-white">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-white/20 transition active:scale-90"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20">
              <ShieldAlert className="h-7 w-7" />
            </div>
            <div>
              <h2 className="font-display text-xl font-extrabold">SOS Emergency</h2>
              <p className="text-sm text-white/80">SuperGoo Safety Alert</p>
            </div>
          </div>
        </div>

        <div className="p-5">
          {/* Confirm phase */}
          {phase === 'confirm' && (
            <div>
              <div className="mb-4 flex items-center gap-2 rounded-xl bg-error-50 px-4 py-3">
                <MapPin className="h-4 w-4 flex-shrink-0 text-error-600" />
                <p className="text-sm font-medium text-error-700">
                  Your location will be shared with your emergency contacts and
                  our support team.
                </p>
              </div>

              <p className="mb-3 text-sm text-neutral-600">
                On trigger, we will:
              </p>
              <ul className="mb-5 space-y-2 text-sm text-neutral-700">
                <li className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4 text-success-600" />
                  Send WhatsApp + SMS to {contacts.length} emergency contact
                  {contacts.length !== 1 ? 's' : ''}
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary-600" />
                  Share your live GPS location
                </li>
                <li className="flex items-center gap-2">
                  <ShieldAlert className="h-4 w-4 text-error-600" />
                  Log an SOS alert with support team
                </li>
              </ul>

              <button
                onClick={handleSos}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-error-600 py-4 text-base font-bold text-white shadow-lg shadow-error-600/30 transition active:scale-95"
              >
                <ShieldAlert className="h-5 w-5" />
                Trigger SOS Now
              </button>

              <div className="mt-3 grid grid-cols-2 gap-3">
                <button
                  onClick={() => callNumber('112')}
                  className="flex items-center justify-center gap-2 rounded-xl bg-neutral-100 py-3 text-sm font-semibold text-neutral-700 transition active:scale-95"
                >
                  <Phone className="h-4 w-4" /> Call 112
                </button>
                <button
                  onClick={() => setPhase('contacts')}
                  className="flex items-center justify-center gap-2 rounded-xl bg-neutral-100 py-3 text-sm font-semibold text-neutral-700 transition active:scale-95"
                >
                  <Users className="h-4 w-4" /> View Contacts
                </button>
              </div>
            </div>
          )}

          {/* Sending phase */}
          {phase === 'sending' && (
            <div className="flex flex-col items-center py-8 text-center">
              <Loader2 className="h-12 w-12 animate-spin text-error-600" />
              <p className="mt-4 font-display text-lg font-bold text-neutral-900">
                Sending SOS...
              </p>
              <p className="mt-1 text-sm text-neutral-500">
                Sharing location with {sentCount}/{contacts.length} contacts
              </p>
            </div>
          )}

          {/* Sent phase */}
          {phase === 'sent' && (
            <div className="text-center">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-success-100">
                <CheckCircle2 className="h-11 w-11 text-success-600" />
              </div>
              <h3 className="mt-4 font-display text-xl font-bold text-neutral-900">
                Help is coming
              </h3>
              <p className="mt-2 text-sm text-neutral-600">
                Your live location has been shared with your family and our
                support team. Stay safe — help is on the way.
              </p>

              <div className="mt-4 rounded-xl bg-neutral-50 p-3 text-left text-xs text-neutral-500">
                <p className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-error-600" />
                  Location: {lat.toFixed(5)}, {lng.toFixed(5)}
                </p>
                <p className="mt-1 flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 text-primary-600" />
                  Notified {contacts.length} emergency contact
                  {contacts.length !== 1 ? 's' : ''}
                </p>
              </div>

              <button
                onClick={() => callNumber('112')}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-error-600 py-3.5 text-sm font-bold text-white transition active:scale-95"
              >
                <Phone className="h-4 w-4" /> Call 112 Emergency
              </button>

              <button
                onClick={onClose}
                className="mt-3 w-full rounded-xl bg-neutral-100 py-3 text-sm font-semibold text-neutral-600 transition active:scale-95"
              >
                Close
              </button>
            </div>
          )}

          {/* Contacts phase */}
          {phase === 'contacts' && (
            <div>
              <button
                onClick={() => setPhase('confirm')}
                className="mb-3 text-sm font-medium text-neutral-500"
              >
                ← Back
              </button>
              {contacts.length === 0 ? (
                <p className="py-6 text-center text-sm text-neutral-400">
                  No emergency contacts added yet. Add them from Profile →
                  Emergency Contacts.
                </p>
              ) : (
                <div className="space-y-2">
                  {contacts.map((c) => (
                    <div
                      key={c.id}
                      className="flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3"
                    >
                      <div>
                        <p className="text-sm font-semibold text-neutral-800">
                          {c.name}
                        </p>
                        <p className="text-xs text-neutral-400">
                          {c.relationship} · {c.phone}
                        </p>
                      </div>
                      <button
                        onClick={() => callNumber(c.phone)}
                        className="flex h-9 w-9 items-center justify-center rounded-lg bg-success-100 text-success-600"
                      >
                        <Phone className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <button
                onClick={handleSos}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-error-600 py-3.5 text-sm font-bold text-white transition active:scale-95"
              >
                <ShieldAlert className="h-5 w-5" /> Trigger SOS Now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
