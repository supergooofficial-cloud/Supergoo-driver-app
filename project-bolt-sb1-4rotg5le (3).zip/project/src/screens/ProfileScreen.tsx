import { useState, useEffect } from 'react';
import {
  User,
  Phone,
  Bike,
  Star,
  LogOut,
  ChevronRight,
  Shield,
  MapPin,
  Car,
  Loader2,
  Check,
  Heart,
  ShieldCheck,
  Users,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  supabase,
  type Driver,
  type Gender,
} from '@/lib/supabase';
import { getEmergencyContacts } from '@/lib/safety';

export default function ProfileScreen({
  onBecomeDriver,
  onOpenDriverMode,
  onOpenEmergencyContacts,
}: {
  onBecomeDriver: () => void;
  onOpenDriverMode: () => void;
  onOpenEmergencyContacts: () => void;
}) {
  const { profile, signOut, refreshProfile } = useAuth();
  const [driver, setDriver] = useState<Driver | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.full_name ?? '');
  const [saving, setSaving] = useState(false);
  const [contactCount, setContactCount] = useState(0);
  const [safetyLoading, setSafetyLoading] = useState(false);
  const [genderOpen, setGenderOpen] = useState(false);

  useEffect(() => {
    setName(profile?.full_name ?? '');
  }, [profile]);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', profile.id)
        .maybeSingle();
      if (data) setDriver(data as Driver);
      setLoading(false);

      try {
        const contacts = await getEmergencyContacts(profile.id);
        setContactCount(contacts.length);
      } catch {
        // ignore
      }
    })();
  }, [profile]);

  const saveName = async () => {
    if (!profile || !name.trim()) return;
    setSaving(true);
    await supabase
      .from('profiles')
      .update({ full_name: name.trim() })
      .eq('id', profile.id);
    await refreshProfile();
    setSaving(false);
    setEditing(false);
  };

  const toggleSafetyMode = async () => {
    if (!profile) return;
    setSafetyLoading(true);
    const next = !profile.safety_mode;
    await supabase
      .from('profiles')
      .update({ safety_mode: next })
      .eq('id', profile.id);
    await refreshProfile();
    setSafetyLoading(false);
  };

  const setGender = async (gender: Gender) => {
    if (!profile) return;
    setGenderOpen(false);
    await supabase
      .from('profiles')
      .update({ gender })
      .eq('id', profile.id);
    await refreshProfile();
  };

  if (!profile) return null;

  const isFemale = profile.gender === 'female';
  const safetyOn = profile.safety_mode;

  return (
    <div className="flex h-full flex-col bg-neutral-50">
      {/* Header */}
      <div
        className={`px-5 pb-20 pt-14 text-white ${
          safetyOn && isFemale
            ? 'bg-gradient-to-br from-pink-500 to-rose-600'
            : 'bg-gradient-to-br from-primary-600 to-primary-800'
        }`}
      >
        <h1 className="font-display text-2xl font-extrabold">Profile</h1>
        <p className="mt-0.5 text-sm text-white/80">Manage your account</p>
      </div>

      {/* Avatar card */}
      <div className="relative -mt-14 px-4">
        <div className="card p-5">
          <div className="flex items-center gap-4">
            <div
              className={`flex h-16 w-16 items-center justify-center rounded-full text-2xl font-bold text-white shadow-lg ${
                safetyOn && isFemale
                  ? 'bg-gradient-to-br from-pink-500 to-rose-600'
                  : 'bg-gradient-to-br from-primary-500 to-primary-700'
              }`}
            >
              {(profile.full_name ?? profile.phone ?? 'U')
                .charAt(0)
                .toUpperCase()}
            </div>
            <div className="flex-1">
              {editing ? (
                <div className="flex items-center gap-2">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="flex-1 rounded-lg border border-neutral-200 px-3 py-2 text-sm font-semibold focus:border-primary-500 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={saveName}
                    className="flex h-9 w-9 items-center justify-center rounded-lg bg-success-600 text-white"
                  >
                    {saving ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Check className="h-4 w-4" />
                    )}
                  </button>
                </div>
              ) : (
                <>
                  <p className="font-display text-lg font-bold text-neutral-900">
                    {profile.full_name ?? 'Add your name'}
                  </p>
                  <button
                    onClick={() => setEditing(true)}
                    className="text-xs font-medium text-primary-600 hover:text-primary-700"
                  >
                    Edit name
                  </button>
                </>
              )}
              <p className="mt-1 flex items-center gap-1.5 text-sm text-neutral-500">
                <Phone className="h-3.5 w-3.5" />
                {profile.phone}
              </p>
              {/* Gender selector */}
              <div className="mt-2">
                {genderOpen ? (
                  <div className="flex gap-1.5">
                    {(['female', 'male', 'other'] as Gender[]).map((g) => (
                      <button
                        key={g}
                        onClick={() => setGender(g)}
                        className={`rounded-lg px-2.5 py-1 text-xs font-semibold capitalize transition ${
                          profile.gender === g
                            ? 'bg-primary-600 text-white'
                            : 'bg-neutral-100 text-neutral-600'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                ) : (
                  <button
                    onClick={() => setGenderOpen(true)}
                    className="text-xs font-medium text-neutral-500 hover:text-neutral-700"
                  >
                    Gender: {profile.gender ?? 'Not set (tap to set)'}
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2 rounded-xl bg-primary-50 px-4 py-3">
            <Shield className="h-5 w-5 text-primary-600" />
            <span className="text-sm font-medium text-primary-700">
              Verified SuperGoo Rider
            </span>
          </div>
        </div>
      </div>

      {/* Safety section */}
      <div className="mt-4 flex-1 overflow-y-auto px-4 pb-6">
        <h2 className="mb-3 px-1 text-xs font-bold uppercase tracking-wide text-neutral-400">
          Safety
        </h2>

        {/* Women Safety Mode toggle */}
        <div className="card mb-3 overflow-hidden">
          <button
            onClick={toggleSafetyMode}
            disabled={safetyLoading || !isFemale}
            className="flex w-full items-center justify-between p-4 text-left transition active:scale-[0.99] disabled:opacity-60"
          >
            <div className="flex items-center gap-3">
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                  safetyOn && isFemale
                    ? 'bg-pink-100'
                    : 'bg-neutral-100'
                }`}
              >
                <ShieldCheck
                  className={`h-6 w-6 ${
                    safetyOn && isFemale
                      ? 'text-pink-600'
                      : 'text-neutral-500'
                  }`}
                />
              </div>
              <div>
                <p className="font-semibold text-neutral-900">
                  Women Safety Mode
                </p>
                <p className="text-xs text-neutral-500">
                  {isFemale
                    ? safetyOn
                      ? 'ON — Auto-share rides & 30-sec live tracking'
                      : 'Off — Tap to enable enhanced safety'
                    : 'Only available for female users'}
                </p>
              </div>
            </div>
            <div
              className={`flex h-7 w-12 items-center rounded-full p-1 transition ${
                safetyOn && isFemale ? 'bg-pink-500' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  safetyOn && isFemale ? 'translate-x-5' : ''
                }`}
              />
            </div>
          </button>
        </div>

        {/* Emergency Contacts */}
        <button
          onClick={onOpenEmergencyContacts}
          className="card mb-3 flex w-full items-center justify-between p-4 text-left transition active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-pink-100">
              <Users className="h-6 w-6 text-pink-600" />
            </div>
            <div>
              <p className="font-semibold text-neutral-900">
                Emergency Contacts
              </p>
              <p className="text-xs text-neutral-500">
                {contactCount > 0
                  ? `${contactCount} contact${contactCount !== 1 ? 's' : ''} added`
                  : 'Add family & friends for SOS'}
              </p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-neutral-400" />
        </button>

        {/* Driver section */}
        <h2 className="mb-3 mt-6 px-1 text-xs font-bold uppercase tracking-wide text-neutral-400">
          Driver
        </h2>

        {loading ? (
          <div className="card flex items-center justify-center p-6">
            <Loader2 className="h-6 w-6 animate-spin text-primary-600" />
          </div>
        ) : driver ? (
          <button
            onClick={onOpenDriverMode}
            className="card flex w-full items-center justify-between p-4 text-left transition active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent-100">
                <Bike className="h-6 w-6 text-accent-600" />
              </div>
              <div>
                <p className="font-semibold text-neutral-900">
                  Switch to Driver Mode
                </p>
                <p className="text-xs text-neutral-500">
                  {driver.is_online ? 'Online' : 'Offline'} ·{' '}
                  {driver.total_rides} rides · {driver.rating.toFixed(1)} ★
                </p>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-neutral-400" />
          </button>
        ) : (
          <button
            onClick={onBecomeDriver}
            className="card flex w-full items-center justify-between p-4 text-left transition active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neutral-100">
                <Car className="h-6 w-6 text-neutral-600" />
              </div>
              <div>
                <p className="font-semibold text-neutral-900">
                  Become a Driver
                </p>
                <p className="text-xs text-neutral-500">
                  Earn money giving rides
                </p>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-neutral-400" />
          </button>
        )}

        {/* Menu items */}
        <h2 className="mb-3 mt-6 px-1 text-xs font-bold uppercase tracking-wide text-neutral-400">
          More
        </h2>
        <div className="card divide-y divide-neutral-50">
          {[
            {
              icon: MapPin,
              label: 'Service Areas',
              sub: 'Andhra Pradesh & Konaseema',
            },
            { icon: Star, label: 'Rate SuperGoo Ride', sub: 'Help us improve' },
            { icon: Shield, label: 'Privacy & Safety', sub: 'Your security matters' },
          ].map((item) => (
            <button
              key={item.label}
              className="flex w-full items-center gap-3 p-4 text-left transition hover:bg-neutral-50"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-neutral-100">
                <item.icon className="h-5 w-5 text-neutral-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-neutral-800">
                  {item.label}
                </p>
                <p className="text-xs text-neutral-400">{item.sub}</p>
              </div>
              <ChevronRight className="h-5 w-5 text-neutral-300" />
            </button>
          ))}
        </div>

        {/* Sign out */}
        <button
          onClick={signOut}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-error-50 py-3.5 text-sm font-semibold text-error-700 transition active:scale-[0.98]"
        >
          <LogOut className="h-4 w-4" /> Sign Out
        </button>

        <p className="mt-6 flex items-center justify-center gap-1 text-center text-xs text-neutral-400">
          <Heart className="h-3 w-3 text-pink-400" />
          SuperGoo Ride v1.0 · Made for Andhra &amp; Konaseema
        </p>
      </div>
    </div>
  );
}
