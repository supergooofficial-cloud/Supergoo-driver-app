import { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Plus,
  Trash2,
  Phone,
  User,
  Heart,
  Users,
  Loader2,
  Shield,
  Check,
  X,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  getEmergencyContacts,
  addEmergencyContact,
  deleteEmergencyContact,
} from '@/lib/safety';
import type { EmergencyContact } from '@/lib/supabase';

const RELATIONSHIPS: { id: EmergencyContact['relationship']; label: string }[] = [
  { id: 'mother', label: 'Mother' },
  { id: 'father', label: 'Father' },
  { id: 'friend', label: 'Friend' },
  { id: 'other', label: 'Other' },
];

const RELATIONSHIP_ICONS: Record<EmergencyContact['relationship'], typeof Heart> = {
  mother: Heart,
  father: Heart,
  friend: Users,
  other: User,
};

export default function EmergencyContactsScreen({
  onBack,
}: {
  onBack: () => void;
}) {
  const { profile } = useAuth();
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [relationship, setRelationship] =
    useState<EmergencyContact['relationship']>('mother');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!profile) return;
    (async () => {
      try {
        const data = await getEmergencyContacts(profile.id);
        setContacts(data);
      } catch {
        // ignore
      }
      setLoading(false);
    })();
  }, [profile]);

  const handleAdd = async () => {
    if (!profile) return;
    if (!name.trim() || phone.replace(/\D/g, '').length < 10) {
      setError('Enter a valid name and 10-digit phone number');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const digits = phone.replace(/\D/g, '');
      const fullPhone =
        digits.length === 10 ? `+91${digits}` : `+${digits}`;
      const contact = await addEmergencyContact(
        profile.id,
        name,
        fullPhone,
        relationship,
      );
      setContacts([...contacts, contact]);
      setName('');
      setPhone('');
      setRelationship('mother');
      setShowAdd(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add contact');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteEmergencyContact(id);
      setContacts(contacts.filter((c) => c.id !== id));
    } catch {
      // ignore
    }
  };

  return (
    <div className="flex h-full flex-col bg-neutral-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-500 to-rose-600 px-5 pb-8 pt-14 text-white">
        <button
          onClick={onBack}
          className="mb-3 flex items-center gap-1 text-sm font-medium text-white/80 hover:text-white"
        >
          <ChevronLeft className="h-4 w-4" /> Profile
        </button>
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/20">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-extrabold">
              Emergency Contacts
            </h1>
            <p className="text-sm text-white/80">
              Notified instantly when you trigger SOS
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-6 pt-4">
        {/* Info banner */}
        <div className="mb-4 flex items-start gap-2 rounded-xl bg-pink-50 px-4 py-3 ring-1 ring-pink-200">
          <Shield className="mt-0.5 h-4 w-4 flex-shrink-0 text-pink-600" />
          <p className="text-xs text-pink-800">
            Add up to 3 trusted contacts. When you press SOS during a ride, they
            instantly receive your live location via WhatsApp & SMS.
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-7 w-7 animate-spin text-pink-600" />
          </div>
        ) : contacts.length === 0 && !showAdd ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-pink-100">
              <Users className="h-8 w-8 text-pink-500" />
            </div>
            <p className="mt-4 font-semibold text-neutral-700">
              No contacts yet
            </p>
            <p className="mt-1 text-sm text-neutral-400">
              Add family or friends to notify in emergencies
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {contacts.map((c) => {
              const Icon = RELATIONSHIP_ICONS[c.relationship] ?? User;
              return (
                <div key={c.id} className="card flex items-center gap-3 p-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-pink-100">
                    <Icon className="h-5 w-5 text-pink-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-neutral-900">{c.name}</p>
                    <p className="text-xs capitalize text-neutral-400">
                      {c.relationship} · {c.phone}
                    </p>
                  </div>
                  <button
                    onClick={() => (window.location.href = `tel:${c.phone}`)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg bg-success-100 text-success-600 transition active:scale-90"
                  >
                    <Phone className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(c.id)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg bg-error-50 text-error-600 transition active:scale-90"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Add form */}
        {showAdd && (
          <div className="mt-4 animate-slide-up rounded-2xl border border-pink-200 bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-base font-bold text-neutral-900">
                Add Contact
              </h3>
              <button
                onClick={() => {
                  setShowAdd(false);
                  setError('');
                  setName('');
                  setPhone('');
                }}
                className="flex h-7 w-7 items-center justify-center rounded-full bg-neutral-100 text-neutral-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
                  Name
                </label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. Lakshmi (Mother)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoFocus
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
                  Phone Number
                </label>
                <div className="flex items-stretch overflow-hidden rounded-xl border border-neutral-200 focus-within:border-pink-500 focus-within:ring-4 focus-within:ring-pink-500/10">
                  <span className="flex items-center border-r border-neutral-200 bg-neutral-50 px-3 text-sm font-medium text-neutral-600">
                    +91
                  </span>
                  <input
                    type="tel"
                    inputMode="numeric"
                    className="flex-1 px-3 py-3 text-sm font-medium focus:outline-none"
                    placeholder="98765 43210"
                    value={phone}
                    maxLength={10}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
                  Relationship
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {RELATIONSHIPS.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setRelationship(r.id)}
                      className={`rounded-lg py-2 text-xs font-semibold capitalize transition ${
                        relationship === r.id
                          ? 'bg-pink-600 text-white'
                          : 'bg-neutral-100 text-neutral-600'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {error && (
              <p className="mt-3 text-sm text-error-600">{error}</p>
            )}

            <button
              onClick={handleAdd}
              disabled={saving}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-pink-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-pink-600/25 transition active:scale-95 disabled:opacity-50"
            >
              {saving ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  <Check className="h-5 w-5" /> Save Contact
                </>
              )}
            </button>
          </div>
        )}

        {/* Add button */}
        {!showAdd && contacts.length < 3 && (
          <button
            onClick={() => setShowAdd(true)}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-pink-300 py-4 text-sm font-semibold text-pink-600 transition hover:bg-pink-50 active:scale-[0.98]"
          >
            <Plus className="h-5 w-5" /> Add Emergency Contact
          </button>
        )}

        {contacts.length >= 3 && !showAdd && (
          <p className="mt-4 text-center text-xs text-neutral-400">
            Maximum 3 emergency contacts reached
          </p>
        )}
      </div>
    </div>
  );
}
