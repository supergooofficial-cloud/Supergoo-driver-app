import { useState, useEffect, useRef, useMemo } from 'react';
import {
  Navigation,
  Phone,
  MessageSquare,
  Star,
  X,
  Loader2,
  MapPin,
  CheckCircle2,
  Clock,
  IndianRupee,
  Share2,
  Shield,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import MapView from '@/components/MapView';
import SosButton from '@/components/SosButton';
import SosModal from '@/components/SosModal';
import { useAuth } from '@/context/AuthContext';
import {
  supabase,
  type Ride,
  type Profile,
  type Driver,
  type VehicleType,
  type EmergencyContact,
} from '@/lib/supabase';
import { getVehicle } from '@/lib/vehicles';
import { calculateFare, type FareBreakdown } from '@/lib/fare';
import {
  getEmergencyContacts,
  buildRideShareMessage,
  openWhatsApp,
} from '@/lib/safety';

const STATUS_FLOW: Record<string, { label: string; step: number }> = {
  searching_driver: { label: 'Searching for driver...', step: 0 },
  searching: { label: 'Finding your driver...', step: 0 },
  accepted: { label: 'Driver assigned', step: 1 },
  en_route: { label: 'Driver on the way', step: 2 },
  started: { label: 'Ride in progress', step: 3 },
  completed: { label: 'Ride completed', step: 4 },
  cancelled: { label: 'Ride cancelled', step: -1 },
};

export default function RideTracking({
  ride,
  onCompleted,
  onCancelled,
}: {
  ride: Ride;
  onCompleted: () => void;
  onCancelled: () => void;
}) {
  const { profile } = useAuth();
  const [currentRide, setCurrentRide] = useState(ride);
  const [driver, setDriver] = useState<Driver | null>(null);
  const [driverProfile, setDriverProfile] = useState<Profile | null>(null);
  const [simulatedDriverPos, setSimulatedDriverPos] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [sosOpen, setSosOpen] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [shared, setShared] = useState(false);
  const simIntervalRef = useRef<number | null>(null);
  const safetyTrackRef = useRef<number | null>(null);

  const safetyMode = profile?.safety_mode ?? false;
  const isFemale = profile?.gender === 'female';

  // Load emergency contacts
  useEffect(() => {
    if (!profile) return;
    getEmergencyContacts(profile.id).then(setContacts).catch(() => {});
  }, [profile]);

  // Subscribe to ride changes
  useEffect(() => {
    const channel = supabase
      .channel(`ride-${currentRide.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'rides',
          filter: `id=eq.${currentRide.id}`,
        },
        (payload) => {
          const updated = payload.new as Ride;
          setCurrentRide(updated);
          if (updated.status === 'completed') {
            setTimeout(() => onCompleted(), 1500);
          }
          if (updated.status === 'cancelled') {
            setTimeout(() => onCancelled(), 1500);
          }
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentRide.id, onCompleted, onCancelled]);

  // Load driver info when driver_id is set
  useEffect(() => {
    if (!currentRide.driver_id) return;
    (async () => {
      const { data: d } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', currentRide.driver_id!)
        .maybeSingle();
      if (d) setDriver(d as Driver);

      const { data: p } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentRide.driver_id!)
        .maybeSingle();
      if (p) setDriverProfile(p as Profile);
    })();
  }, [currentRide.driver_id]);

  // Simulate driver approaching
  useEffect(() => {
    if (
      !currentRide.driver_id ||
      currentRide.status === 'completed' ||
      currentRide.status === 'cancelled' ||
      currentRide.status === 'started'
    ) {
      if (simIntervalRef.current) {
        clearInterval(simIntervalRef.current);
        simIntervalRef.current = null;
      }
      return;
    }

    const targetLat = currentRide.pickup_lat;
    const targetLng = currentRide.pickup_lng;
    let driverLat = targetLat + 0.01;
    let driverLng = targetLng + 0.01;
    setSimulatedDriverPos({ lat: driverLat, lng: driverLng });

    simIntervalRef.current = window.setInterval(() => {
      const dLat = (targetLat - driverLat) * 0.15;
      const dLng = (targetLng - driverLng) * 0.15;
      driverLat += dLat;
      driverLng += dLng;
      setSimulatedDriverPos({ lat: driverLat, lng: driverLng });

      supabase
        .from('rides')
        .update({ driver_lat: driverLat, driver_lng: driverLng })
        .eq('id', currentRide.id)
        .then(() => {});

      if (Math.abs(targetLat - driverLat) < 0.001) {
        // Driver has arrived — do NOT auto-start. Driver must enter OTP to start the ride.
        if (simIntervalRef.current) {
          clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
      }
    }, 2000);

    return () => {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
    };
  }, [
    currentRide.driver_id,
    currentRide.status,
    currentRide.id,
    currentRide.pickup_lat,
    currentRide.pickup_lng,
  ]);

  // Auto-assign a driver after a few seconds if searching for one
  useEffect(() => {
    if (currentRide.status !== 'searching_driver' && currentRide.status !== 'searching') return;
    const timer = setTimeout(async () => {
      // Try to find an online driver with a matching vehicle type
      let driverQuery = supabase
        .from('drivers')
        .select('id')
        .eq('is_online', true);
      if (currentRide.vehicle_type) {
        driverQuery = driverQuery.eq('vehicle_type', currentRide.vehicle_type);
      }
      const { data: onlineDrivers } = await driverQuery.limit(1).maybeSingle();

      const driverId = onlineDrivers?.id;

      if (driverId) {
        await supabase
          .from('rides')
          .update({ driver_id: driverId, status: 'accepted' })
          .eq('id', currentRide.id);
      } else {
        // No matching online driver yet — keep searching
      }
    }, 4000);

    return () => clearTimeout(timer);
  }, [currentRide.status, currentRide.id, currentRide.vehicle_type]);

  // After accepted → en_route, then start moving
  useEffect(() => {
    if (currentRide.status === 'accepted') {
      const t = setTimeout(() => {
        supabase
          .from('rides')
          .update({ status: 'en_route' })
          .eq('id', currentRide.id)
          .then(() => {});
      }, 3000);
      return () => clearTimeout(t);
    }
    if (currentRide.status === 'started') {
      const t = setTimeout(() => {
        supabase
          .from('rides')
          .update({
            status: 'completed',
            completed_at: new Date().toISOString(),
          })
          .eq('id', currentRide.id)
          .then(() => {});
      }, 8000);
      return () => clearTimeout(t);
    }
  }, [currentRide.status, currentRide.id]);

  // Women Safety Mode: auto-share ride + track every 30 sec
  useEffect(() => {
    const shouldTrack =
      safetyMode &&
      isFemale &&
      currentRide.status !== 'completed' &&
      currentRide.status !== 'cancelled';

    if (!shouldTrack) {
      if (safetyTrackRef.current) {
        clearInterval(safetyTrackRef.current);
        safetyTrackRef.current = null;
      }
      return;
    }

    // Auto-share ride with contacts once at start
    if (contacts.length > 0 && !shared) {
      const msg = buildRideShareMessage(
        profile?.full_name ?? 'SuperGoo Rider',
        currentRide.id,
        currentRide.pickup_lat,
        currentRide.pickup_lng,
      );
      for (const c of contacts) {
        openWhatsApp(c.phone, msg);
      }
      setShared(true);
    }

    // Track every 30 seconds — update sos_alerts or a tracking log
    safetyTrackRef.current = window.setInterval(() => {
      navigator.geolocation?.getCurrentPosition(
        (pos) => {
          supabase
            .from('rides')
            .update({
              driver_lat: pos.coords.latitude,
              driver_lng: pos.coords.longitude,
            })
            .eq('id', currentRide.id)
            .then(() => {});
        },
        () => {},
        { enableHighAccuracy: true, timeout: 5000 },
      );
    }, 30000);

    return () => {
      if (safetyTrackRef.current) clearInterval(safetyTrackRef.current);
    };
  }, [
    safetyMode,
    isFemale,
    currentRide.status,
    currentRide.id,
    currentRide.pickup_lat,
    currentRide.pickup_lng,
    contacts,
    shared,
    profile?.full_name,
  ]);

  const cancelRide = async () => {
    await supabase
      .from('rides')
      .update({ status: 'cancelled' })
      .eq('id', currentRide.id);
  };

  const handleShareRide = () => {
    const msg = buildRideShareMessage(
      profile?.full_name ?? 'SuperGoo Rider',
      currentRide.id,
      currentRide.pickup_lat,
      currentRide.pickup_lng,
    );
    openWhatsApp('', msg);
  };

  const statusInfo = STATUS_FLOW[currentRide.status] ?? STATUS_FLOW.searching_driver;
  const isCompleted = currentRide.status === 'completed';
  const isCancelled = currentRide.status === 'cancelled';
  const isActive = !isCompleted && !isCancelled;
  const vehicleType: VehicleType = currentRide.vehicle_type ?? 'auto';
  const vehicleCfg = getVehicle(vehicleType);
  const VehicleIcon = vehicleCfg.icon;

  const fareBreakdown = useMemo<FareBreakdown>(() => {
    const estDuration = Math.max(5, Math.round(currentRide.distance_km * 3));
    return calculateFare(currentRide.distance_km, estDuration, vehicleType);
  }, [currentRide.distance_km, vehicleType]);

  const driverPos =
    simulatedDriverPos ??
    (currentRide.driver_lat != null && currentRide.driver_lng != null
      ? { lat: currentRide.driver_lat, lng: currentRide.driver_lng }
      : null);

  const sosLat = driverPos?.lat ?? currentRide.pickup_lat;
  const sosLng = driverPos?.lng ?? currentRide.pickup_lng;

  const markers: {
    type: 'user' | 'driver' | 'pickup' | 'drop';
    lat: number;
    lng: number;
    vehicle?: VehicleType;
  }[] = [];
  if (driverPos && currentRide.status !== 'started')
    markers.push({
      type: 'driver',
      lat: driverPos.lat,
      lng: driverPos.lng,
      vehicle: vehicleType,
    });
  markers.push({
    type: 'pickup',
    lat: currentRide.pickup_lat,
    lng: currentRide.pickup_lng,
  });
  if (currentRide.status === 'started') {
    markers.push({
      type: 'drop',
      lat: currentRide.drop_lat,
      lng: currentRide.drop_lng,
    });
  }

  const route =
    currentRide.status === 'started'
      ? ([
          [currentRide.pickup_lat, currentRide.pickup_lng],
          [currentRide.drop_lat, currentRide.drop_lng],
        ] as [[number, number], [number, number]])
      : driverPos
        ? ([
            [driverPos.lat, driverPos.lng],
            [currentRide.pickup_lat, currentRide.pickup_lng],
          ] as [[number, number], [number, number]])
        : null;

  return (
    <div
      className={`relative flex h-full flex-col ${
        safetyMode && isFemale
          ? 'ring-4 ring-pink-500 ring-inset'
          : ''
      }`}
    >
      {/* Map */}
      <div className="absolute inset-0">
        <MapView
          center={[currentRide.pickup_lat, currentRide.pickup_lng]}
          zoom={15}
          markers={markers}
          route={route}
          fitToMarkers={!!route}
        />
      </div>

      {/* Safety mode banner */}
      {safetyMode && isFemale && (
        <div className="absolute left-0 right-0 top-0 z-10 flex items-center justify-center gap-2 bg-pink-500 py-1.5 text-center text-xs font-bold text-white shadow-md">
          <Shield className="h-3.5 w-3.5" />
          Women Safety Mode is ON — Live tracking active
        </div>
      )}

      {/* Status header */}
      <div
        className={`relative z-10 mx-4 flex items-center justify-between ${
          safetyMode && isFemale ? 'mt-10' : 'mt-4'
        }`}
      >
        <div className="flex items-center gap-2.5 rounded-full bg-white/90 px-4 py-2.5 shadow-md backdrop-blur">
          {(currentRide.status === 'searching' || currentRide.status === 'searching_driver') ? (
            <Loader2 className="h-4 w-4 animate-spin text-primary-600" />
          ) : isCompleted ? (
            <CheckCircle2 className="h-4 w-4 text-success-600" />
          ) : (
            <VehicleIcon className={`h-4 w-4 ${vehicleCfg.color}`} />
          )}
          <span className="text-sm font-semibold text-neutral-800">
            {statusInfo.label}
          </span>
        </div>
        {isActive && (
          <button
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur transition active:scale-90"
            onClick={cancelRide}
            title="Cancel ride"
          >
            <X className="h-5 w-5 text-error-600" />
          </button>
        )}
      </div>

      {/* SOS button — always visible during active ride */}
      {isActive && (
        <div className="absolute bottom-[340px] right-4 z-20">
          <SosButton onClick={() => setSosOpen(true)} />
        </div>
      )}

      {/* SOS modal */}
      {sosOpen && (
        <SosModal
          ride={currentRide}
          userId={profile?.id ?? ''}
          userName={profile?.full_name ?? 'SuperGoo Rider'}
          contacts={contacts}
          lat={sosLat}
          lng={sosLng}
          onClose={() => setSosOpen(false)}
        />
      )}

      {/* Bottom sheet */}
      <div className="relative z-10 mt-auto rounded-t-[1.5rem] bg-white px-5 pb-6 pt-5 shadow-2xl animate-slide-up">
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-neutral-200" />

        {/* Progress steps */}
        {!isCancelled && (
          <div className="mb-4 flex items-center gap-1.5">
            {['searching', 'accepted', 'en_route', 'started', 'completed'].map(
              (s, i) => (
                <div
                  key={s}
                  className={`h-1.5 flex-1 rounded-full transition-all ${
                    i <= statusInfo.step ? 'bg-primary-600' : 'bg-neutral-200'
                  }`}
                />
              ),
            )}
          </div>
        )}

        {/* Searching state */}
        {(currentRide.status === 'searching' || currentRide.status === 'searching_driver') && (
          <div className="flex flex-col items-center py-6 text-center">
            <div className="relative">
              <div className="absolute inset-0 animate-pulse-ring rounded-full bg-primary-200" />
              <div
                className={`relative flex h-16 w-16 items-center justify-center rounded-full text-white ${vehicleCfg.color.replace('text-', 'bg-')}`}
              >
                <VehicleIcon className="h-8 w-8" />
              </div>
            </div>
            <p className="mt-4 font-display text-lg font-bold text-neutral-900">
              Finding your {vehicleCfg.label.toLowerCase()} driver
            </p>
            <p className="mt-1 text-sm text-neutral-500">
              Connecting you with nearby {vehicleCfg.label.toLowerCase()}s...
            </p>
          </div>
        )}

        {/* Driver info */}
        {currentRide.driver_id && !isCompleted && !isCancelled && (
          <div className="animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-primary-700 text-lg font-bold text-white">
                  {(driverProfile?.full_name ?? 'R').charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold text-neutral-900">
                    {driverProfile?.full_name ?? 'Your rider'}
                  </p>
                  <p className="text-sm text-neutral-500">
                    {driver?.vehicle_model ?? `${vehicleCfg.label} Taxi`}
                  </p>
                  <p className="text-xs font-medium text-primary-600">
                    {driver?.vehicle_number ?? 'AP 00 AB 1234'}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-accent-400 text-accent-400" />
                  <span className="font-bold text-neutral-900">
                    {driver?.rating?.toFixed(1) ?? '5.0'}
                  </span>
                </div>
                <p className="text-xs text-neutral-400">
                  {driver?.total_rides ?? 0} rides
                </p>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2">
              <button className="flex items-center justify-center gap-1.5 rounded-xl bg-success-50 py-3 text-xs font-semibold text-success-700 transition active:scale-95">
                <Phone className="h-4 w-4" /> Call
              </button>
              <button className="flex items-center justify-center gap-1.5 rounded-xl bg-primary-50 py-3 text-xs font-semibold text-primary-700 transition active:scale-95">
                <MessageSquare className="h-4 w-4" /> Chat
              </button>
              <button
                onClick={handleShareRide}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-pink-50 py-3 text-xs font-semibold text-pink-700 transition active:scale-95"
              >
                <Share2 className="h-4 w-4" /> Share
              </button>
            </div>

            <div className="mt-4 flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-neutral-400" />
                <span className="text-sm font-medium text-neutral-600">
                  Drop: {currentRide.drop_address}
                </span>
              </div>
            </div>

            {/* Ride OTP — share with driver */}
            {currentRide.ride_otp && currentRide.status !== 'started' && !isCompleted && !isCancelled && (
              <div className="mt-4 rounded-2xl bg-gradient-to-br from-accent-50 to-accent-100 p-4 ring-1 ring-accent-200/50">
                <div className="flex items-center gap-2">
                  <KeyRound className="h-5 w-5 text-accent-600" />
                  <p className="text-sm font-semibold text-accent-800">
                    Share this OTP with driver to start ride
                  </p>
                </div>
                <div className="mt-3 flex items-center justify-center gap-3">
                  {currentRide.ride_otp.split('').map((digit, i) => (
                    <div
                      key={i}
                      className="flex h-12 w-12 items-center justify-center rounded-xl bg-white text-2xl font-extrabold text-neutral-900 shadow-sm ring-1 ring-accent-200"
                    >
                      {digit}
                    </div>
                  ))}
                </div>
                <p className="mt-2 text-center text-xs text-accent-600/70">
                  Driver must enter this OTP to start the ride
                </p>
              </div>
            )}

            {/* OTP verified indicator once ride started */}
            {currentRide.ride_otp && currentRide.status === 'started' && (
              <div className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-success-50 px-4 py-3 ring-1 ring-success-200">
                <ShieldCheck className="h-5 w-5 text-success-600" />
                <span className="text-sm font-semibold text-success-700">
                  OTP verified — ride started
                </span>
              </div>
            )}
          </div>
        )}

        {/* Completed state */}
        {isCompleted && (
          <div className="animate-bounce-in py-2 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success-100">
              <CheckCircle2 className="h-9 w-9 text-success-600" />
            </div>
            <p className="mt-3 font-display text-xl font-bold text-neutral-900">
              Ride completed!
            </p>
            <p className="mt-1 text-sm text-neutral-500">
              Hope you enjoyed your SuperGoo Ride
            </p>
            {/* Fare breakdown */}
            <div className="mt-4 rounded-xl bg-neutral-50 p-4 text-left ring-1 ring-neutral-100">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Fare Breakdown
              </p>
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-600">Distance</span>
                  <span className="font-medium text-neutral-800">{fareBreakdown.distanceKm} km</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-600">Base fare (first 1.5 km)</span>
                  <span className="font-medium text-neutral-800">₹{fareBreakdown.baseFare}</span>
                </div>
                {fareBreakdown.distanceCharge > 0 && (
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-600">
                      Distance charge (@₹{vehicleCfg.perKm}/km)
                    </span>
                    <span className="font-medium text-neutral-800">₹{fareBreakdown.distanceCharge}</span>
                  </div>
                )}
                {fareBreakdown.rawTotal !== fareBreakdown.total && (
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-400">Subtotal</span>
                    <span className="text-neutral-400 line-through">₹{fareBreakdown.rawTotal}</span>
                  </div>
                )}
              </div>
              <div className="mt-3 flex items-center justify-between border-t border-neutral-200 pt-3">
                <span className="text-sm font-bold text-neutral-900">Total</span>
                <span className="font-display text-2xl font-extrabold text-success-600">
                  ₹{fareBreakdown.total}
                </span>
              </div>
              <p className="mt-2 text-center text-xs text-neutral-500">paid via cash/UPI</p>
            </div>
          </div>
        )}

        {/* Cancelled state */}
        {isCancelled && (
          <div className="py-6 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-error-100">
              <X className="h-9 w-9 text-error-600" />
            </div>
            <p className="mt-3 font-display text-xl font-bold text-neutral-900">
              Ride cancelled
            </p>
          </div>
        )}

        {/* ETA & fare */}
        {!isCompleted && !isCancelled && currentRide.driver_id && (
          <div className="mt-4 flex items-center justify-between rounded-xl bg-primary-50 px-4 py-3">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary-600" />
              <span className="text-sm font-medium text-primary-700">
                {currentRide.status === 'started'
                  ? 'On the way to destination'
                  : 'Arriving soon'}
              </span>
            </div>
            <span className="font-display text-lg font-bold text-neutral-900">
              ₹{currentRide.fare}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
