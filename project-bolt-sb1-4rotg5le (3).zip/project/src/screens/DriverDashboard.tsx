import { useState, useEffect, useMemo } from 'react';
import {
  Bike,
  Power,
  Star,
  Navigation,
  MapPin,
  IndianRupee,
  Clock,
  X,
  Check,
  Loader2,
  TrendingUp,
  Zap,
  User,
  ChevronLeft,
  KeyRound,
} from 'lucide-react';
import MapView from '@/components/MapView';
import { useLiveLocation } from '@/hooks/useLiveLocation';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Ride, type Driver as DriverType, type VehicleType } from '@/lib/supabase';
import { getVehicle } from '@/lib/vehicles';
import { calculateFare, type FareBreakdown } from '@/lib/fare';

export default function DriverDashboard({
  onExitDriverMode,
}: {
  onExitDriverMode: () => void;
}) {
  const { profile } = useAuth();
  const { lat, lng, refresh } = useLiveLocation(false);
  const [driver, setDriver] = useState<DriverType | null>(null);
  const [loading, setLoading] = useState(true);
  const [incomingRide, setIncomingRide] = useState<Ride | null>(null);
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [accepting, setAccepting] = useState(false);
  const [todayEarnings, setTodayEarnings] = useState(0);
  const [todayRides, setTodayRides] = useState(0);
  const [otpInput, setOtpInput] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpVerifying, setOtpVerifying] = useState(false);

  // Load driver record
  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', profile.id)
        .maybeSingle();
      if (data) setDriver(data as DriverType);
      setLoading(false);
    })();
  }, [profile]);

  // Load today's stats
  useEffect(() => {
    if (!profile) return;
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    (async () => {
      const { data } = await supabase
        .from('rides')
        .select('fare, status')
        .eq('driver_id', profile.id)
        .gte('created_at', startOfDay.toISOString());
      if (data) {
        const completed = (data as Pick<Ride, 'fare' | 'status'>[]).filter(
          (r) => r.status === 'completed',
        );
        setTodayRides(completed.length);
        setTodayEarnings(completed.reduce((s, r) => s + r.fare, 0));
      }
    })();
  }, [profile, activeRide]);

  // Update driver location when online
  useEffect(() => {
    if (!profile || !driver?.is_online || lat == null || lng == null) return;
    supabase
      .from('drivers')
      .update({
        current_lat: lat,
        current_lng: lng,
        updated_at: new Date().toISOString(),
      })
      .eq('id', profile.id)
      .then(() => {});
  }, [lat, lng, profile, driver?.is_online]);

  // Subscribe to new ride requests via realtime when online and no active ride
  useEffect(() => {
    if (!profile || !driver?.is_online || activeRide) {
      return;
    }

    // Initial fetch for any pending rides (in case one was created before subscription)
    const fetchPending = async () => {
      let query = supabase
        .from('rides')
        .select('*')
        .eq('status', 'searching_driver')
        .is('driver_id', null);
      if (driver?.vehicle_type) {
        query = query.eq('vehicle_type', driver.vehicle_type);
      }
      const { data } = await query
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();
      if (data) setIncomingRide(data as Ride);
    };
    fetchPending();

    // Realtime: listen for new rides inserted with searching_driver status
    const channel = supabase
      .channel('driver-incoming-rides')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'rides',
        },
        (payload) => {
          const newRide = payload.new as Ride;
          if (
            newRide.status === 'searching_driver' &&
            !newRide.driver_id &&
            (!driver?.vehicle_type || newRide.vehicle_type === driver.vehicle_type)
          ) {
            setIncomingRide(newRide);
          }
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile, driver?.is_online, driver?.vehicle_type, activeRide]);

  // Subscribe to active ride changes
  useEffect(() => {
    if (!activeRide) return;
    const channel = supabase
      .channel(`driver-ride-${activeRide.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'rides',
          filter: `id=eq.${activeRide.id}`,
        },
        (payload) => {
          const updated = payload.new as Ride;
          setActiveRide(updated);
          if (updated.status === 'completed' || updated.status === 'cancelled') {
            setTimeout(() => setActiveRide(null), 2000);
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeRide?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleOnline = async () => {
    if (!profile || !driver) return;
    const next = !driver.is_online;
    setDriver({ ...driver, is_online: next });
    await supabase
      .from('drivers')
      .update({ is_online: next })
      .eq('id', profile.id);
    if (next && lat == null) refresh();
  };

  const acceptRide = async () => {
    if (!incomingRide || !profile) return;
    setAccepting(true);
    const { error } = await supabase
      .from('rides')
      .update({ driver_id: profile.id, status: 'accepted' })
      .eq('id', incomingRide.id);
    if (error) {
      setAccepting(false);
      return;
    }
    setActiveRide({ ...incomingRide, driver_id: profile.id, status: 'accepted' });
    setIncomingRide(null);
    setAccepting(false);
  };

  const rejectRide = () => setIncomingRide(null);

  const advanceRide = async (newStatus: string) => {
    if (!activeRide) return;

    if (newStatus === 'started') {
      if (!activeRide.ride_otp) return;
      setOtpVerifying(true);
      setOtpError('');
      if (otpInput.trim() !== activeRide.ride_otp) {
        setOtpError('Incorrect OTP. Ask the customer for the 4-digit code.');
        setOtpVerifying(false);
        return;
      }
      const updates: Record<string, unknown> = { status: newStatus };
      const { error } = await supabase
        .from('rides')
        .update(updates)
        .eq('id', activeRide.id);
      if (error) {
        setOtpError('Could not start ride. Try again.');
        setOtpVerifying(false);
        return;
      }
      setOtpVerifying(false);
      setOtpInput('');
      return;
    }

    const updates: Record<string, unknown> = { status: newStatus };
    if (newStatus === 'completed') {
      updates.completed_at = new Date().toISOString();
      if (driver) {
        await supabase
          .from('drivers')
          .update({ total_rides: driver.total_rides + 1 })
          .eq('id', profile!.id);
      }
    }
    await supabase.from('rides').update(updates).eq('id', activeRide.id);
  };

  const incomingFare = useMemo<FareBreakdown | null>(() => {
    if (!incomingRide) return null;
    const estDuration = Math.max(5, Math.round(incomingRide.distance_km * 3));
    return calculateFare(incomingRide.distance_km, estDuration, incomingRide.vehicle_type ?? 'auto');
  }, [incomingRide]);

  const activeFare = useMemo<FareBreakdown | null>(() => {
    if (!activeRide) return null;
    const estDuration = Math.max(5, Math.round(activeRide.distance_km * 3));
    return calculateFare(activeRide.distance_km, estDuration, activeRide.vehicle_type ?? 'auto');
  }, [activeRide]);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-neutral-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
      </div>
    );
  }

  const isOnline = driver?.is_online ?? false;
  const center: [number, number] =
    lat != null && lng != null ? [lat, lng] : [16.869, 81.929];

  const markers: { type: 'user' | 'pickup' | 'drop' | 'driver'; lat: number; lng: number; vehicle?: VehicleType }[] = [];
  if (lat != null && lng != null)
    markers.push({ type: 'driver', lat, lng });
  if (activeRide) {
    markers.push({ type: 'pickup', lat: activeRide.pickup_lat, lng: activeRide.pickup_lng });
    if (activeRide.status === 'started')
      markers.push({ type: 'drop', lat: activeRide.drop_lat, lng: activeRide.drop_lng });
  }

  return (
    <div className="relative flex h-full flex-col">
      {/* Map */}
      <div className="absolute inset-0">
        <MapView center={center} zoom={14} markers={markers} />
      </div>

      {/* Top bar */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-4">
        <button
          onClick={onExitDriverMode}
          className="flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-2 text-sm font-medium text-neutral-700 shadow-md backdrop-blur"
        >
          <ChevronLeft className="h-4 w-4" /> Rider
        </button>
        <div
          className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold shadow-md backdrop-blur ${
            isOnline
              ? 'bg-success-50 text-success-700'
              : 'bg-white/90 text-neutral-600'
          }`}
        >
          <span
            className={`h-2 w-2 rounded-full ${
              isOnline ? 'animate-pulse bg-success-500' : 'bg-neutral-400'
            }`}
          />
          {isOnline ? 'Online' : 'Offline'}
        </div>
      </div>

      {/* Incoming ride request modal */}
      {incomingRide && !activeRide && (
        <div className="absolute inset-0 z-30 flex items-end bg-black/40 animate-fade-in">
          <div className="w-full max-h-[88%] overflow-y-auto rounded-t-[1.5rem] bg-white px-5 pb-8 pt-6 shadow-2xl animate-slide-up">
            <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-neutral-200" />
            <div className="flex items-center gap-2">
              <div className={`relative flex h-12 w-12 items-center justify-center rounded-full text-white ${getVehicle(incomingRide.vehicle_type ?? 'auto').color.replace('text-', 'bg-')}`}>
                {(() => { const V = getVehicle(incomingRide.vehicle_type ?? 'auto').icon; return <V className="h-6 w-6" />; })()}
                <span className="absolute inset-0 animate-pulse-ring rounded-full bg-primary-400" />
              </div>
              <div>
                <p className="font-display text-lg font-bold text-neutral-900">
                  New {getVehicle(incomingRide.vehicle_type ?? 'auto').label} Ride Request!
                </p>
                <p className="text-sm text-neutral-500">
                  {incomingRide.distance_km} km
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-2.5 rounded-xl bg-neutral-50 p-4">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-success-600" />
                <span className="font-medium text-neutral-700">
                  {incomingRide.pickup_address}
                </span>
              </div>
              <div className="ml-2 border-l-2 border-dashed border-neutral-200 pl-4">
                <div className="flex items-center gap-2 text-sm">
                  <Navigation className="h-4 w-4 text-error-600" />
                  <span className="font-medium text-neutral-700">
                    {incomingRide.drop_address}
                  </span>
                </div>
              </div>
            </div>

            {/* Fare breakdown for driver */}
            {incomingFare && (
              <div className="mt-4 rounded-xl bg-primary-50 p-4 ring-1 ring-primary-200/50">
                <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-primary-700">
                  Fare Breakdown
                </p>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-600">Distance</span>
                    <span className="font-medium text-neutral-800">{incomingFare.distanceKm} km</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-600">Base fare (first 1.5 km)</span>
                    <span className="font-medium text-neutral-800">₹{incomingFare.baseFare}</span>
                  </div>
                  {incomingFare.distanceCharge > 0 && (
                    <div className="flex justify-between text-xs">
                      <span className="text-neutral-600">Distance charge</span>
                      <span className="font-medium text-neutral-800">₹{incomingFare.distanceCharge}</span>
                    </div>
                  )}
                  {incomingFare.rawTotal !== incomingFare.total && (
                    <div className="flex justify-between text-xs">
                      <span className="text-neutral-500">Subtotal</span>
                      <span className="font-medium text-neutral-500 line-through">₹{incomingFare.rawTotal}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-primary-200/40 pt-1.5">
                    <span className="text-sm font-bold text-neutral-900">Total fare</span>
                    <span className="font-display text-xl font-extrabold text-primary-700">
                      ₹{incomingFare.total}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Ride OTP for driver reference */}
            {incomingRide.ride_otp && (
              <div className="mt-3 flex items-center justify-between rounded-xl bg-accent-50 px-4 py-3 ring-1 ring-accent-200/50">
                <div className="flex items-center gap-2">
                  <KeyRound className="h-5 w-5 text-accent-600" />
                  <span className="text-sm font-medium text-accent-800">
                    Ride OTP (ask customer)
                  </span>
                </div>
                <span className="font-display text-lg font-extrabold tracking-widest text-accent-700">
                  {incomingRide.ride_otp}
                </span>
              </div>
            )}

            <div className="mt-5 flex gap-3">
              <button
                onClick={rejectRide}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-neutral-100 py-3.5 text-sm font-semibold text-neutral-700 transition active:scale-95"
              >
                <X className="h-5 w-5" /> Decline
              </button>
              <button
                onClick={acceptRide}
                disabled={accepting}
                className="flex flex-[2] items-center justify-center gap-2 rounded-xl bg-success-600 py-3.5 text-sm font-semibold text-white shadow-lg shadow-success-600/25 transition active:scale-95 disabled:opacity-50"
              >
                {accepting ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    <Check className="h-5 w-5" /> Accept Ride
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active ride panel */}
      {activeRide && (
        <div className="relative z-20 mt-auto max-h-[72%] overflow-y-auto rounded-t-[1.5rem] bg-white px-5 pb-6 pt-5 shadow-2xl animate-slide-up">
          <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-neutral-200" />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
                <User className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <p className="font-semibold text-neutral-900">
                  {activeRide.pickup_address}
                </p>
                <p className="text-xs text-neutral-500">
                  → {activeRide.drop_address}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-display text-xl font-bold text-neutral-900">
                ₹{activeRide.fare}
              </p>
              <p className="text-xs text-neutral-400">
                {activeRide.distance_km} km
              </p>
            </div>
          </div>

          {/* Fare breakdown in active ride */}
          {activeFare && (
            <div className="mt-3 rounded-xl bg-neutral-50 p-3 ring-1 ring-neutral-100">
              <p className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-neutral-500">
                Fare Breakdown
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-500">Base (1.5 km)</span>
                  <span className="font-medium text-neutral-700">₹{activeFare.baseFare}</span>
                </div>
                {activeFare.distanceCharge > 0 && (
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-500">Distance charge</span>
                    <span className="font-medium text-neutral-700">₹{activeFare.distanceCharge}</span>
                  </div>
                )}
                {activeFare.rawTotal !== activeFare.total && (
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-400">Subtotal</span>
                    <span className="text-neutral-400 line-through">₹{activeFare.rawTotal}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-neutral-200 pt-1">
                  <span className="text-xs font-semibold text-neutral-700">Total</span>
                  <span className="text-sm font-bold text-primary-700">₹{activeFare.total}</span>
                </div>
              </div>
            </div>
          )}

          <div className="mt-3 flex items-center gap-2 text-sm">
            {(() => {
              const vt = activeRide.vehicle_type ?? 'auto';
              const vc = getVehicle(vt);
              const VIcon = vc.icon;
              return (
                <span className={`chip ${vc.activeBg} ${vc.activeColor}`}>
                  <VIcon className="h-3 w-3" /> {vc.label}
                </span>
              );
            })()}
            <span
              className={`chip ${
                activeRide.status === 'completed'
                  ? 'bg-success-100 text-success-700'
                  : activeRide.status === 'cancelled'
                    ? 'bg-error-100 text-error-700'
                    : 'bg-primary-100 text-primary-700'
              }`}
            >
              {activeRide.status.replace('_', ' ')}
            </span>
          </div>

          {/* Action buttons based on status */}
          <div className="mt-4 flex gap-3">
            {activeRide.status === 'accepted' && (
              <button
                onClick={() => advanceRide('en_route')}
                className="btn-primary flex-1"
              >
                <Navigation className="h-5 w-5" /> Start to Pickup
              </button>
            )}
            {activeRide.status === 'en_route' && (
              <div className="mt-4">
                <div className="rounded-xl bg-accent-50 p-4 ring-1 ring-accent-200/50">
                  <div className="flex items-center gap-2">
                    <KeyRound className="h-5 w-5 text-accent-600" />
                    <p className="text-sm font-semibold text-accent-800">
                      Enter OTP from customer to start ride
                    </p>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={4}
                      value={otpInput}
                      onChange={(e) => {
                        setOtpInput(e.target.value.replace(/\D/g, ''));
                        setOtpError('');
                      }}
                      placeholder="4-digit OTP"
                      className="flex-1 rounded-xl border-2 border-accent-200 bg-white px-4 py-3 text-center text-xl font-bold tracking-[0.5em] text-neutral-900 outline-none focus:border-accent-500"
                    />
                    <button
                      onClick={() => advanceRide('started')}
                      disabled={otpInput.length !== 4 || otpVerifying}
                      className="flex items-center justify-center gap-2 rounded-xl bg-success-600 px-5 py-3.5 text-sm font-semibold text-white shadow-lg shadow-success-600/25 transition active:scale-95 disabled:opacity-40"
                    >
                      {otpVerifying ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <>
                          <Bike className="h-5 w-5" /> Start
                        </>
                      )}
                    </button>
                  </div>
                  {otpError && (
                    <p className="mt-2 text-sm font-medium text-error-600">{otpError}</p>
                  )}
                </div>
              </div>
            )}
            {activeRide.status === 'started' && (
              <button
                onClick={() => advanceRide('completed')}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-success-600 py-3.5 text-sm font-semibold text-white shadow-lg shadow-success-600/25 transition active:scale-95"
              >
                <Check className="h-5 w-5" /> Complete Ride
              </button>
            )}
            {(activeRide.status === 'completed' ||
              activeRide.status === 'cancelled') && (
              <div className="flex-1 text-center text-sm font-semibold text-neutral-600">
                {activeRide.status === 'completed'
                  ? 'Ride completed! Waiting for next request...'
                  : 'Ride cancelled'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Default dashboard (no active ride) */}
      {!activeRide && !incomingRide && (
        <div className="relative z-10 mt-auto rounded-t-[1.5rem] bg-white px-5 pb-6 pt-5 shadow-2xl animate-slide-up">
          <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-neutral-200" />

          {/* Online/Offline toggle */}
          <button
            onClick={toggleOnline}
            className={`flex w-full items-center justify-between rounded-2xl p-4 transition ${
              isOnline
                ? 'bg-gradient-to-r from-success-500 to-success-600 text-white'
                : 'bg-neutral-100 text-neutral-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                  isOnline ? 'bg-white/20' : 'bg-white'
                }`}
              >
                <Power className="h-6 w-6" />
              </div>
              <div className="text-left">
                <p className="font-display text-lg font-bold">
                  {isOnline ? "You're Online" : "You're Offline"}
                </p>
                <p className={`text-sm ${isOnline ? 'text-white/80' : 'text-neutral-500'}`}>
                  {isOnline
                    ? 'Receiving ride requests'
                    : 'Go online to get rides'}
                </p>
              </div>
            </div>
            <div
              className={`flex h-7 w-12 items-center rounded-full p-1 transition ${
                isOnline ? 'bg-white/30' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  isOnline ? 'translate-x-5' : ''
                }`}
              />
            </div>
          </button>

          {/* Stats */}
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-xl bg-neutral-50 p-4 text-center">
              <IndianRupee className="mx-auto h-5 w-5 text-success-600" />
              <p className="mt-1.5 font-display text-lg font-bold text-neutral-900">
                {todayEarnings}
              </p>
              <p className="text-xs text-neutral-400">Today</p>
            </div>
            <div className="rounded-xl bg-neutral-50 p-4 text-center">
              <TrendingUp className="mx-auto h-5 w-5 text-primary-600" />
              <p className="mt-1.5 font-display text-lg font-bold text-neutral-900">
                {todayRides}
              </p>
              <p className="text-xs text-neutral-400">Rides</p>
            </div>
            <div className="rounded-xl bg-neutral-50 p-4 text-center">
              <Star className="mx-auto h-5 w-5 text-accent-500" />
              <p className="mt-1.5 font-display text-lg font-bold text-neutral-900">
                {driver?.rating.toFixed(1) ?? '5.0'}
              </p>
              <p className="text-xs text-neutral-400">Rating</p>
            </div>
          </div>

          {/* Driver info */}
          <div className="mt-4 flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3">
            <div className="flex items-center gap-2">
              <Bike className="h-5 w-5 text-primary-600" />
              <div>
                <p className="text-sm font-semibold text-neutral-800">
                  {driver?.vehicle_model ?? 'Bike'}
                </p>
                <p className="text-xs text-neutral-400">
                  {driver?.vehicle_number ?? ''}
                </p>
              </div>
            </div>
            <span className="text-xs text-neutral-400">
              {driver?.total_rides ?? 0} total rides
            </span>
          </div>

          {isOnline && (
            <div className="mt-4 flex items-center justify-center gap-2 text-sm text-neutral-500">
              <Zap className="h-4 w-4 animate-pulse text-accent-500" />
              Waiting for ride requests...
            </div>
          )}
        </div>
      )}
    </div>
  );
}
