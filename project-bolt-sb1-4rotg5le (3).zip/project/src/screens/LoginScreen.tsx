import { useState, useRef } from 'react';
import type { ConfirmationResult } from 'firebase/auth';
import { Phone, Shield, ArrowRight, Bike, Loader2, ChevronLeft } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

type Step = 'phone' | 'otp';

export default function LoginScreen() {
  const { sendOtp, verifyOtp, refreshProfile } = useAuth();
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const confirmationRef = useRef<ConfirmationResult | null>(null);
  const recaptchaReady = useRef(false);

  const fullPhone = `+91${phone.replace(/\D/g, '')}`;

  const handleSendOtp = async () => {
    const digits = phone.replace(/\D/g, '');
    if (digits.length !== 10) {
      setError('Enter a valid 10-digit mobile number');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const confirmation = await sendOtp(fullPhone, 'recaptcha-container');
      confirmationRef.current = confirmation;
      recaptchaReady.current = true;
      setStep('otp');
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Could not send OTP. Please try again.',
      );
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 6) {
      setError('Enter the 6-digit code');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await verifyOtp(confirmationRef.current!, otp);
      await refreshProfile();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Invalid code. Try again.',
      );
    } finally {
      setLoading(false);
    }
  };

  const resendOtp = async () => {
    setLoading(true);
    setError('');
    try {
      const confirmation = await sendOtp(fullPhone, 'recaptcha-container');
      confirmationRef.current = confirmation;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resend OTP');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-gradient-to-b from-primary-700 via-primary-800 to-neutral-900">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-primary-500/20 blur-3xl" />
      <div className="pointer-events-none absolute top-40 -left-20 h-64 w-64 rounded-full bg-accent-500/15 blur-3xl" />

      {/* Top brand */}
      <div className="relative flex flex-col items-center px-6 pt-20 pb-8 text-center text-white">
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white/10 backdrop-blur-md ring-1 ring-white/20">
          <Bike className="h-10 w-10 text-accent-400" strokeWidth={2.2} />
        </div>
        <h1 className="mt-5 font-display text-3xl font-extrabold tracking-tight">
          SuperGoo Ride
        </h1>
        <p className="mt-1.5 text-sm text-primary-100/80">
          Bike taxis across Andhra &amp; Konaseema
        </p>
      </div>

      {/* reCAPTCHA — always mounted so resend works from OTP step too */}
      <div id="recaptcha-container" className="flex justify-center" />

      {/* Bottom sheet */}
      <div className="relative mt-auto animate-slide-up rounded-t-[2rem] bg-white px-6 pb-10 pt-8 shadow-2xl">
        {step === 'phone' && (
          <>
            <h2 className="font-display text-2xl font-bold text-neutral-900">
              Welcome aboard
            </h2>
            <p className="mt-1.5 text-sm text-neutral-500">
              Login with your mobile number to start riding
            </p>

            <div className="mt-7">
              <label className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Mobile Number
              </label>
              <div className="mt-2 flex items-stretch overflow-hidden rounded-xl border border-neutral-200 bg-white transition-all focus-within:border-primary-500 focus-within:ring-4 focus-within:ring-primary-500/10">
                <div className="flex items-center gap-1.5 border-r border-neutral-200 bg-neutral-50 px-4 text-sm font-medium text-neutral-700">
                  <Phone className="h-3.5 w-3.5 text-primary-600" />
                  +91
                </div>
                <input
                  type="tel"
                  inputMode="numeric"
                  className="flex-1 px-4 py-3.5 text-base font-medium text-neutral-900 placeholder-neutral-400 focus:outline-none"
                  placeholder="98765 43210"
                  value={phone}
                  maxLength={10}
                  onChange={(e) =>
                    setPhone(e.target.value.replace(/\D/g, ''))
                  }
                  onKeyDown={(e) => e.key === 'Enter' && handleSendOtp()}
                  autoFocus
                />
              </div>
            </div>

            {error && (
              <p className="mt-3 text-sm text-error-600">{error}</p>
            )}

            <button
              className="btn-primary mt-4 w-full text-base"
              onClick={handleSendOtp}
              disabled={loading || phone.length !== 10}
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  Send OTP <ArrowRight className="h-5 w-5" />
                </>
              )}
            </button>

            <div className="mt-5 flex items-center justify-center gap-2 text-xs text-neutral-400">
              <Shield className="h-3.5 w-3.5" />
              Secured with Firebase Phone Auth
            </div>
          </>
        )}

        {step === 'otp' && (
          <>
            <button
              className="mb-4 flex items-center gap-1 text-sm font-medium text-neutral-500 hover:text-neutral-700"
              onClick={() => {
                setStep('phone');
                setOtp('');
                setError('');
                confirmationRef.current = null;
              }}
            >
              <ChevronLeft className="h-4 w-4" /> Change number
            </button>

            <h2 className="font-display text-2xl font-bold text-neutral-900">
              Verify OTP
            </h2>
            <p className="mt-1.5 text-sm text-neutral-500">
              Enter the 6-digit code sent to{' '}
              <span className="font-semibold text-neutral-700">
                {fullPhone}
              </span>
            </p>

            <div className="mt-7">
              <input
                type="tel"
                inputMode="numeric"
                className="otp-input w-full rounded-xl border border-neutral-200 bg-white px-4 py-4 text-center text-2xl font-bold tracking-[0.6em] text-neutral-900 placeholder-neutral-300 transition-all focus:border-primary-500 focus:outline-none focus:ring-4 focus:ring-primary-500/10"
                placeholder="------"
                value={otp}
                maxLength={6}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                onKeyDown={(e) => e.key === 'Enter' && handleVerifyOtp()}
                autoFocus
              />
            </div>

            {error && (
              <p className="mt-3 text-sm text-error-600">{error}</p>
            )}

            <button
              className="btn-primary mt-6 w-full text-base"
              onClick={handleVerifyOtp}
              disabled={loading || otp.length !== 6}
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>Verify &amp; Continue</>
              )}
            </button>

            <button
              className="mt-4 w-full text-center text-sm font-medium text-primary-600 hover:text-primary-700"
              onClick={resendOtp}
              disabled={loading}
            >
              Resend OTP
            </button>
          </>
        )}
      </div>
    </div>
  );
}
