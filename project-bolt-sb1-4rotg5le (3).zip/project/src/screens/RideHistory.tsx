import { useState, useEffect } from 'react';
import {
  History,
  IndianRupee,
  MapPin,
  Navigation,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Star,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Ride, type VehicleType } from '@/lib/supabase';
import { getVehicle } from '@/lib/vehicles';

export default function RideHistory() {
  const { profile } = useAuth();
  const [rides, setRides] = useState<Ride[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data, error } = await supabase
        .from('rides')
        .select('*')
        .eq('customer_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) {
        console.error(error);
        setLoading(false);
        return;
      }
      setRides((data as Ride[]) ?? []);
      setLoading(false);
    })();
  }, [profile]);

  const completed = rides.filter((r) => r.status === 'completed');
  const totalSpent = completed.reduce((sum, r) => sum + r.fare, 0);

  return (
    <div className="flex h-full flex-col bg-neutral-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary-600 to-primary-800 px-5 pb-8 pt-14 text-white">
        <h1 className="font-display text-2xl font-extrabold">Your Rides</h1>
        <p className="mt-0.5 text-sm text-primary-100/80">
          Ride history and summary
        </p>

        {completed.length > 0 && (
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/10 p-4 backdrop-blur ring-1 ring-white/20">
              <p className="text-xs text-primary-100/70">Total Rides</p>
              <p className="mt-1 font-display text-2xl font-bold">
                {completed.length}
              </p>
            </div>
            <div className="rounded-2xl bg-white/10 p-4 backdrop-blur ring-1 ring-white/20">
              <p className="text-xs text-primary-100/70">Total Spent</p>
              <p className="mt-1 font-display text-2xl font-bold">
                ₹{totalSpent}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-4 pb-6 pt-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 text-neutral-400">
            <Loader2 className="h-8 w-8 animate-spin" />
            <p className="mt-3 text-sm">Loading rides...</p>
          </div>
        ) : rides.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-neutral-100">
              <History className="h-8 w-8 text-neutral-400" />
            </div>
            <p className="mt-4 font-semibold text-neutral-700">
              No rides yet
            </p>
            <p className="mt-1 text-sm text-neutral-400">
              Book your first SuperGoo Ride to see it here
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {rides.map((ride) => (
              <div key={ride.id} className="card p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {ride.status === 'completed' ? (
                        <CheckCircle2 className="h-4 w-4 text-success-600" />
                      ) : ride.status === 'cancelled' ? (
                        <XCircle className="h-4 w-4 text-error-600" />
                      ) : (
                        <Clock className="h-4 w-4 text-warning-500" />
                      )}
                      <span className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                        {ride.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="mt-3 space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-success-100">
                          <MapPin className="h-3 w-3 text-success-600" />
                        </div>
                        <span className="font-medium text-neutral-700">
                          {ride.pickup_address}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-error-100">
                          <Navigation className="h-3 w-3 text-error-600" />
                        </div>
                        <span className="font-medium text-neutral-700">
                          {ride.drop_address}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="font-display text-xl font-bold text-neutral-900">
                      ₹{ride.fare}
                    </p>
                    <p className="text-xs text-neutral-400">
                      {ride.distance_km} km
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-2 border-t border-neutral-50 pt-3">
                  {(() => {
                    const vt: VehicleType = ride.vehicle_type ?? 'bike';
                    const vc = getVehicle(vt);
                    const VIcon = vc.icon;
                    return (
                      <span className={`chip ${vc.activeBg} ${vc.activeColor}`}>
                        <VIcon className="h-3 w-3" /> {vc.label}
                      </span>
                    );
                  })()}
                  <span className="ml-auto text-xs text-neutral-400">
                    {new Date(ride.created_at).toLocaleString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
