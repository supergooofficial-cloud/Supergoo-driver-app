import { useState } from 'react';
import { ArrowRight, Loader2, ChevronLeft, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type VehicleType } from '@/lib/supabase';
import { VEHICLES, getVehicle } from '@/lib/vehicles';

export default function DriverRegistration({
  onDone,
  onBack,
}: {
  onDone: () => void;
  onBack: () => void;
}) {
  const { profile, refreshProfile } = useAuth();
  const [drivenVehicleType, setDrivenVehicleType] = useState<VehicleType>('bike');
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const selectedVehicle = getVehicle(drivenVehicleType);

  const submit = async () => {
    if (!profile) return;
    if (!vehicleModel.trim() || !vehicleNumber.trim()) {
      setError('Please fill all details');
      return;
    }
    setLoading(true);
    setError('');
    try {
      if (fullName.trim() && fullName !== profile.full_name) {
        await supabase
          .from('profiles')
          .update({ full_name: fullName.trim(), role: 'driver' })
          .eq('id', profile.id);
      } else {
        await supabase
          .from('profiles')
          .update({ role: 'driver' })
          .eq('id', profile.id);
      }

      await supabase.from('drivers').insert({
        id: profile.id,
        vehicle_model: vehicleModel.trim(),
        vehicle_number: vehicleNumber.trim().toUpperCase(),
        vehicle_type: drivenVehicleType,
        is_online: false,
        rating: 5.0,
        total_rides: 0,
      });

      await refreshProfile();
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const modelPlaceholder =
    drivenVehicleType === 'bike'
      ? 'e.g. Honda Activa 6G'
      : drivenVehicleType === 'auto'
        ? 'e.g. Bajaj RE Auto'
        : drivenVehicleType === 'cab_mini'
          ? 'e.g. Maruti Swift'
          : 'e.g. Maruti Ertiga';

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-accent-600 to-neutral-900">
      <div className="px-5 pt-14 text-white">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-sm font-medium text-white/80 hover:text-white"
        >
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
        <div className="mt-6 flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 ring-1 ring-white/20">
            <selectedVehicle.icon className="h-8 w-8 text-accent-300" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-extrabold">
              Become a Driver
            </h1>
            <p className="text-sm text-white/70">
              Start earning with your vehicle
            </p>
          </div>
        </div>
      </div>

      <div className="mt-auto rounded-t-[2rem] bg-white px-6 pb-10 pt-7 shadow-2xl animate-slide-up">
        <div className="mx-auto mb-5 h-1.5 w-10 rounded-full bg-neutral-200" />

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
              Full Name
            </label>
            <input
              type="text"
              className="input-field"
              placeholder="Enter your full name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>

          {/* Vehicle type selector */}
          <div>
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
              Vehicle Type
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {VEHICLES.map((v) => {
                const isSelected = v.id === drivenVehicleType;
                const Icon = v.icon;
                return (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => setDrivenVehicleType(v.id)}
                    className={`flex flex-col items-center gap-1.5 rounded-2xl px-2 py-3 text-center ring-1 transition-all active:scale-95 ${
                      isSelected
                        ? `${v.activeBg} ${v.activeColor} ring-2`
                        : 'bg-neutral-50 text-neutral-600 ring-neutral-100 hover:bg-neutral-100'
                    }`}
                  >
                    <Icon className="h-7 w-7" strokeWidth={isSelected ? 2.5 : 2} />
                    <span className="text-xs font-bold">{v.label}</span>
                    <span className="text-[10px] leading-tight text-neutral-400">{v.capacity}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
              {getVehicle(drivenVehicleType).label} Model
            </label>
            <input
              type="text"
              className="input-field"
              placeholder={modelPlaceholder}
              value={vehicleModel}
              onChange={(e) => setVehicleModel(e.target.value)}
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-neutral-500">
              Vehicle Number
            </label>
            <input
              type="text"
              className="input-field uppercase"
              placeholder="e.g. AP 28 AB 1234"
              value={vehicleNumber}
              onChange={(e) => setVehicleNumber(e.target.value)}
            />
          </div>
        </div>

        {error && <p className="mt-3 text-sm text-error-600">{error}</p>}

        <button
          className="btn-primary mt-6 w-full text-base"
          disabled={loading}
          onClick={submit}
        >
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <>
              Start Driving <ArrowRight className="h-5 w-5" />
            </>
          )}
        </button>

        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-neutral-400">
          <CheckCircle2 className="h-3.5 w-3.5 text-success-500" />
          Quick registration · Start earning today
        </div>
      </div>
    </div>
  );
}
