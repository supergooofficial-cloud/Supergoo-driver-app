import { useState, useEffect, useCallback } from 'react';
import {
  Bike,
  Navigation,
  MapPin,
  Clock,
  Search,
  Loader2,
  AlertCircle,
  Crosshair,
  Zap,
  Shield,
  TrendingDown,
  Moon,
  Users,
  ChevronRight,
} from 'lucide-react';
import MapView from '@/components/MapView';
import LocationSearch from '@/components/LocationSearch';
import { useLiveLocation } from '@/hooks/useLiveLocation';
import { useAuth } from '@/context/AuthContext';
import { getAreas, isInServiceArea, haversine } from '@/lib/areas';
import { VEHICLES, getVehicle } from '@/lib/vehicles';
import { supabase, type Ride, type VehicleType } from '@/lib/supabase';
import {
  fetchRouteInfo,
  calculateFare,
  calculateFareForAllVehicles,
  type FareBreakdown,
} from '@/lib/fare';
import type { ServiceableArea } from '@/lib/supabase';

type Place = { name: string; lat: number; lng: number; district?: string };

const DEFAULT_CENTER: [number, number] = [16.869, 81.929]; // Mandapeta

export default function HomeScreen({
  onRideBooked,
}: {
  onRideBooked: (ride: Ride) => void;
}) {
  const { profile } = useAuth();
  const { lat, lng, loading, error, refresh } = useLiveLocation();
  const [areas, setAreas] = useState<ServiceableArea[]>([]);
  const [pickup, setPickup] = useState<Place | null>(null);
  const [drop, setDrop] = useState<Place | null>(null);
  const [vehicleType, setVehicleType] = useState<VehicleType>('auto');
  const [booking, setBooking] = useState(false);
  const [bookingError, setBookingError] = useState('');
  const [serviceError, setServiceError] = useState('');
  const [routeInfo, setRouteInfo] = useState<{
    distanceKm: number;
    durationMin: number;
  } | null>(null);
  const [routeLoading, setRouteLoading] = useState(false);
  const [allFares, setAllFares] = useState<Record<VehicleType, FareBreakdown> | null>(null);

  useEffect(() => {
    getAreas().then(setAreas).catch(() => {});
  }, []);

  useEffect(() => {
    if (lat != null && lng != null && !pickup) {
      setPickup({ name: 'Current Location', lat, lng });
    }
  }, [lat, lng, pickup]);

  useEffect(() => {
    if (lat == null || lng == null || areas.length === 0) {
      setServiceError('');
      return;
    }
    if (!isInServiceArea(lat, lng, areas)) {
      setServiceError(
        'Service not available in your area yet. SuperGoo Ride operates across Andhra Pradesh & Konaseema.',
      );
    } else {
      setServiceError('');
    }
  }, [lat, lng, areas]);

  // Fetch real route info (distance + duration) when both locations are set
  useEffect(() => {
    if (!pickup || !drop) {
      setRouteInfo(null);
      setAllFares(null);
      return;
    }
    let cancelled = false;
    setRouteLoading(true);
    fetchRouteInfo(
      { lat: pickup.lat, lng: pickup.lng },
      { lat: drop.lat, lng: drop.lng },
    ).then((info) => {
      if (cancelled) return;
      if (info) {
        setRouteInfo(info);
        setAllFares(calculateFareForAllVehicles(info.distanceKm, info.durationMin));
      } else {
        const fallbackDist = haversine(pickup.lat, pickup.lng, drop.lat, drop.lng);
        const fallbackTime = Math.max(5, Math.round(fallbackDist * 3));
        setRouteInfo({ distanceKm: fallbackDist, durationMin: fallbackTime });
        setAllFares(calculateFareForAllVehicles(fallbackDist, fallbackTime));
      }
      setRouteLoading(false);
    });
    return () => { cancelled = true; };
  }, [pickup, drop]);

  const center: [number, number] =
    lat != null && lng != null ? [lat, lng] : DEFAULT_CENTER;

  const selectedVehicle = getVehicle(vehicleType);
  const selectedFare = allFares?.[vehicleType] ?? null;

  const markers: { type: 'user' | 'pickup' | 'drop'; lat: number; lng: number }[] = [];
  if (lat != null && lng != null && !pickup)
    markers.push({ type: 'user', lat, lng });
  if (pickup) markers.push({ type: 'pickup', lat: pickup.lat, lng: pickup.lng });
  if (drop) markers.push({ type: 'drop', lat: drop.lat, lng: drop.lng });

  const route =
    pickup && drop
      ? ([[pickup.lat, pickup.lng], [drop.lat, drop.lng]] as [[number, number], [number, number]])
      : null;

  const handleBook = useCallback(async () => {
    if (!pickup || !drop || !profile || !selectedFare) return;
    setBooking(true);
    setBookingError('');
    try {
      const otp = String(Math.floor(1000 + Math.random() * 9000));
      const { data, error } = await supabase
        .from('rides')
        .insert({
          customer_id: profile.id,
          pickup_lat: pickup.lat,
          pickup_lng: pickup.lng,
          pickup_address: pickup.name,
          drop_lat: drop.lat,
          drop_lng: drop.lng,
          drop_address: drop.name,
          distance_km: selectedFare.distanceKm,
          fare: selectedFare.total,
          status: 'searching_driver',
          vehicle_type: vehicleType,
          ride_otp: otp,
        })
        .select()
        .maybeSingle();
      if (error) throw error;
      if (data) onRideBooked(data as Ride);
    } catch (err) {
      setBookingError(
        err instanceof Error ? err.message : 'Could not book ride. Try again.',
      );
    } finally {
      setBooking(false);
    }
  }, [pickup, drop, profile, selectedFare, vehicleType, onRideBooked]);

  const getEtaMin = (vt: VehicleType): number => {
    if (!routeInfo) return 0;
    return Math.max(2, Math.round(routeInfo.durationMin * getVehicle(vt).etaMultiplier * 0.3));
  };

  return (
    <div className="relative flex h-full flex-col">
      {/* Map */}
      <div className="absolute inset-0">
        <MapView
          center={center}
          zoom={14}
          markers={markers}
          route={route}
          fitToMarkers={!!route}
        />
      </div>

      {/* Top bar */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-4">
        <div className="flex items-center gap-2 rounded-full bg-white/90 px-4 py-2 shadow-md backdrop-blur">
          <Bike className="h-5 w-5 text-primary-600" />
          <span className="font-display text-sm font-bold text-neutral-900">
            SuperGoo
          </span>
        </div>
        <button
          className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur transition active:scale-90"
          onClick={refresh}
          title="Re-center"
        >
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin text-primary-600" />
          ) : (
            <Crosshair className="h-5 w-5 text-primary-600" />
          )}
        </button>
      </div>

      {/* GPS error banner */}
      {error && (
        <div className="relative z-10 mx-4 mt-3 flex items-start gap-2 rounded-xl bg-warning-50 px-4 py-3 text-sm text-warning-800 ring-1 ring-warning-200">
          <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Service area error */}
      {serviceError && (
        <div className="relative z-10 mx-4 mt-3 flex items-start gap-2 rounded-xl bg-error-50 px-4 py-3 text-sm text-error-800 ring-1 ring-error-200">
          <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
          <span>{serviceError}</span>
        </div>
      )}

      {/* Bottom sheet */}
      <div className="relative z-10 mt-auto max-h-[78%] overflow-y-auto rounded-t-[1.5rem] bg-white px-5 pb-6 pt-5 shadow-2xl animate-slide-up">
        <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-neutral-200" />

        <h2 className="font-display text-xl font-bold text-neutral-900">
          Where are you going?
        </h2>
        <p className="mt-0.5 text-sm text-neutral-500">
          Choose your ride and book in seconds
        </p>

        {/* Pickup & Drop inputs */}
        <div className="mt-4 space-y-3">
          <LocationSearch
            label="Pickup"
            icon="pickup"
            placeholder="From location"
            value={pickup}
            onSelect={setPickup}
            userLat={lat ?? undefined}
            userLng={lng ?? undefined}
          />
          <LocationSearch
            label="Drop"
            icon="drop"
            placeholder="To location"
            value={drop}
            onSelect={setDrop}
            userLat={lat ?? undefined}
            userLng={lng ?? undefined}
          />
        </div>

        {/* Route summary */}
        {pickup && drop && routeInfo && !routeLoading && (
          <div className="mt-3 flex items-center gap-3 rounded-xl bg-neutral-50 px-4 py-2.5 text-sm">
            <span className="flex items-center gap-1 font-medium text-neutral-700">
              <Navigation className="h-4 w-4 text-primary-600" />
              {routeInfo.distanceKm.toFixed(1)} km
            </span>
            <span className="flex items-center gap-1 font-medium text-neutral-700">
              <Clock className="h-4 w-4 text-primary-600" />
              {routeInfo.durationMin} min
            </span>
            {allFares?.bike.isNight && (
              <span className="ml-auto flex items-center gap-1 rounded-full bg-accent-100 px-2.5 py-0.5 text-xs font-semibold text-accent-700">
                <Moon className="h-3 w-3" /> Night +₹10
              </span>
            )}
          </div>
        )}

        {/* Vehicle comparison cards (Uber/Rapido style) */}
        {pickup && drop && (
          <div className="mt-4 space-y-2.5">
            {routeLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary-600" />
                <span className="ml-2 text-sm text-neutral-500">
                  Calculating fares...
                </span>
              </div>
            ) : (
              allFares && (
                <>
                  <p className="text-xs font-semibold uppercase tracking-wide text-neutral-400">
                    Choose your ride
                  </p>
                  {VEHICLES.map((v) => {
                    const isSelected = v.id === vehicleType;
                    const fare = allFares[v.id];
                    const etaMin = getEtaMin(v.id);
                    const Icon = v.icon;
                    return (
                      <button
                        key={v.id}
                        onClick={() => setVehicleType(v.id)}
                        className={`flex w-full items-center gap-3 rounded-2xl p-3.5 text-left ring-1 transition-all active:scale-[0.98] ${
                          isSelected
                            ? `${v.activeBg} ${v.activeColor} ring-2`
                            : 'bg-neutral-50 text-neutral-600 ring-neutral-100 hover:bg-neutral-100'
                        }`}
                      >
                        {/* Icon */}
                        <div className={`flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl ${isSelected ? 'bg-white shadow-sm' : 'bg-white'}`}>
                          <Icon className="h-7 w-7" strokeWidth={isSelected ? 2.5 : 2} />
                        </div>

                        {/* Label + capacity + ETA */}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-neutral-900">{v.label}</p>
                            <span className="flex items-center gap-0.5 text-xs text-neutral-400">
                              <Users className="h-3 w-3" /> {v.capacity}
                            </span>
                          </div>
                          <div className="mt-0.5 flex items-center gap-2 text-xs">
                            <span className="flex items-center gap-0.5 text-neutral-500">
                              <Clock className="h-3 w-3" /> {etaMin} min away
                            </span>
                            <span className="text-neutral-300">·</span>
                            <span className="text-neutral-400">{v.subLabel}</span>
                          </div>
                          <div className="mt-0.5 text-[11px] text-neutral-400">
                            ₹{v.base} base + ₹{v.perKm}/km + ₹{v.perMin}/min
                          </div>
                        </div>

                        {/* Fare */}
                        <div className="flex flex-col items-end">
                          <span className="font-display text-lg font-extrabold text-neutral-900">
                            ₹{fare.total}
                          </span>
                          {fare.isNight && (
                            <span className="flex items-center gap-0.5 text-[10px] text-accent-600">
                              <Moon className="h-2.5 w-2.5" /> +₹10
                            </span>
                          )}
                          {isSelected && (
                            <ChevronRight className="mt-0.5 h-4 w-4" strokeWidth={2.5} />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </>
              )
            )}
          </div>
        )}

        {/* Fare breakdown for selected vehicle */}
        {pickup && drop && selectedFare && !routeLoading && (
          <div className="mt-3 animate-fade-in rounded-xl bg-gradient-to-br from-primary-50 to-primary-100 p-4 ring-1 ring-primary-200/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`flex h-9 w-9 items-center justify-center rounded-lg text-white ${selectedVehicle.color.replace('text-', 'bg-')}`}>
                  <selectedVehicle.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs font-medium text-primary-700">
                    {selectedVehicle.label} · {selectedFare.distanceKm} km · {selectedFare.durationMin} min
                  </p>
                </div>
              </div>
              <p className="font-display text-2xl font-extrabold text-neutral-900">
                ₹{selectedFare.total}
              </p>
            </div>

            <div className="mt-3 space-y-1.5 border-t border-primary-200/40 pt-3">
              <div className="flex justify-between text-xs">
                <span className="text-neutral-600">Base fare</span>
                <span className="font-medium text-neutral-800">₹{selectedFare.baseFare}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-neutral-600">Distance ({selectedFare.distanceKm} km × ₹{selectedVehicle.perKm})</span>
                <span className="font-medium text-neutral-800">₹{selectedFare.distanceCharge}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-neutral-600">Time ({selectedFare.durationMin} min × ₹{selectedVehicle.perMin})</span>
                <span className="font-medium text-neutral-800">₹{selectedFare.timeCharge}</span>
              </div>
              {selectedFare.nightSurcharge > 0 && (
                <div className="flex justify-between text-xs">
                  <span className="flex items-center gap-1 text-accent-700">
                    <Moon className="h-3 w-3" /> Night surcharge (9 PM–5 AM)
                  </span>
                  <span className="font-medium text-accent-700">₹{selectedFare.nightSurcharge}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {bookingError && (
          <p className="mt-3 text-sm text-error-600">{bookingError}</p>
        )}

        {/* Book button */}
        <button
          className="btn-primary mt-4 w-full text-base"
          disabled={!pickup || !drop || booking || !!serviceError || !selectedFare || routeLoading}
          onClick={handleBook}
        >
          {booking ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" /> Booking your {selectedVehicle.label}...
            </>
          ) : !pickup || !drop ? (
            'Select pickup & drop locations'
          ) : routeLoading || !selectedFare ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" /> Calculating fares...
            </>
          ) : (
            <>
              Book {selectedVehicle.label} · ₹{selectedFare.total}
              <Search className="h-5 w-5" />
            </>
          )}
        </button>

        {/* Feature highlights */}
        {(!pickup || !drop) && (
          <div className="mt-5 grid grid-cols-3 gap-3">
            {[
              { icon: TrendingDown, label: 'Low fares', color: 'text-success-600 bg-success-50' },
              { icon: Zap, label: 'Fast pickup', color: 'text-accent-600 bg-accent-50' },
              { icon: Shield, label: 'Safe rides', color: 'text-primary-600 bg-primary-50' },
            ].map((f) => (
              <div
                key={f.label}
                className="flex flex-col items-center gap-1.5 rounded-xl bg-neutral-50 p-3 text-center"
              >
                <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${f.color}`}>
                  <f.icon className="h-4 w-4" />
                </div>
                <p className="text-xs font-medium text-neutral-600">{f.label}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
