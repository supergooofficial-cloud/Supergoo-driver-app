import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import LoginScreen from '@/screens/LoginScreen';
import HomeScreen from '@/screens/HomeScreen';
import RideTracking from '@/screens/RideTracking';
import RideHistory from '@/screens/RideHistory';
import ProfileScreen from '@/screens/ProfileScreen';
import DriverRegistration from '@/screens/DriverRegistration';
import DriverDashboard from '@/screens/DriverDashboard';
import EmergencyContactsScreen from '@/screens/EmergencyContactsScreen';
import BottomNav, { type Tab } from '@/components/BottomNav';
import { Loader2, Bike } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Ride } from '@/lib/supabase';

type Screen = 'main' | 'tracking' | 'driver-reg' | 'driver-mode' | 'emergency-contacts';

function AppContent() {
  const { firebaseUser, profile, loading } = useAuth();
  const [tab, setTab] = useState<Tab>('home');
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [screen, setScreen] = useState<Screen>('main');

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-neutral-50">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-600 text-white shadow-lg">
          <Bike className="h-8 w-8" />
        </div>
        <Loader2 className="mt-4 h-6 w-6 animate-spin text-primary-600" />
      </div>
    );
  }

  if (!firebaseUser || !profile) {
    return <LoginScreen />;
  }

  // Driver registration flow
  if (screen === 'driver-reg') {
    return (
      <DriverRegistration
        onDone={() => setScreen('driver-mode')}
        onBack={() => setScreen('main')}
      />
    );
  }

  // Driver mode
  if (screen === 'driver-mode') {
    return (
      <DriverDashboard onExitDriverMode={() => setScreen('main')} />
    );
  }

  // Ride tracking
  if (screen === 'tracking' && activeRide) {
    return (
      <RideTracking
        ride={activeRide}
        onCompleted={() => {
          setActiveRide(null);
          setScreen('main');
          setTab('history');
        }}
        onCancelled={() => {
          setActiveRide(null);
          setScreen('main');
        }}
      />
    );
  }

  // Emergency contacts screen
  if (screen === 'emergency-contacts') {
    return <EmergencyContactsScreen onBack={() => setScreen('main')} />;
  }

  // Main customer app
  const checkDriverAndOpen = async () => {
    const { data } = await supabase
      .from('drivers')
      .select('id')
      .eq('id', profile.id)
      .maybeSingle();
    if (data) {
      setScreen('driver-mode');
    } else {
      setScreen('driver-reg');
    }
  };

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-neutral-50">
      <div className="relative flex-1 overflow-hidden">
        {tab === 'home' && (
          <HomeScreen
            onRideBooked={(ride) => {
              setActiveRide(ride);
              setScreen('tracking');
            }}
          />
        )}
        {tab === 'history' && <RideHistory />}
        {tab === 'profile' && (
          <ProfileScreen
            onBecomeDriver={() => setScreen('driver-reg')}
            onOpenDriverMode={checkDriverAndOpen}
            onOpenEmergencyContacts={() => setScreen('emergency-contacts')}
          />
        )}
      </div>
      <BottomNav active={tab} onChange={setTab} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <div className="mx-auto flex h-screen max-w-md flex-col overflow-hidden bg-white shadow-2xl sm:my-0">
        <AppContent />
      </div>
    </AuthProvider>
  );
}
